# -*- coding: utf-8 -*-
"""
Created on Sun Jan 17 23:08:14 2016

@author: Saskia
"""

import arff
import sys
import copy
import numpy as np
import aslib_stats
import random
import time


def main(args):
    t0 = time.time()
    algoruns_index = args.index("--algoruns")
    data = read_files(args[algoruns_index + 1])
    verbose = False
    if "--verbose" in args:
        verbose = True
    #data = read_files("as_exercise6/SAT11-INDU/algorithm_runs.arff")
    t2 = time.time()
    runtimes = create_matrix(data, verbose)
    t3 = time.time()
    assign = find_assignment(runtimes, 5000, verbose)
    t4 = time.time()
    find_permutation(assign, runtimes, 50000, verbose)    
    t1 = time.time()
    if verbose:
        print("Single Best has {!s} timeouts".format(count_timeouts_of_single_best(data)))
        print("runtime read file: {!s}".format(t2-t0))
        print("runtime create matrix: {!s}".format(t3-t2))
        print("runtime find assignment: {!s}".format(t4-t3))
        print("runtime find permutation: {!s}".format(t1-t4))
        print("runtime total: {!s}".format(t1-t0))
        
    
def read_files(filename):
    """
    Function that is just there to read the given file and computes the data 
    part into a list.
    """
    data = arff.load(open(filename))
    raw_data = data["data"]
    return raw_data


def create_matrix(data, verbose):
    """
    Creates a n x m matrix with n being the number of instances and m the 
    number of algorithms.
    """
    num_inst = len(find_amount_of_instances(data))
    num_algos = len(find_amount_of_algorithms(data))
    runtimes = []
    data_copy = copy.copy(data)
    for j in range(0, num_inst):
        inst_runtimes = []
        for i in range(0,num_algos):
            line = data_copy.pop(0)
            inst_runtimes.append(line[3])
        runtimes.append(np.array(inst_runtimes))
    #print(runtimes)
    runtimes = np.array(runtimes)
    #print(runtimes[3][5])
    return runtimes


def find_assignment(runtimes, maxsteps, verbose):
    """ 
    Random local search that finds a time slice assignment for each algorithm.
    Solutions are compared by the number of solvable instances. Solution
    returned might not be the best one, depending on the value of maxsteps.
    Initial solution: for each algorithm find random time slice between 0 and 
    k, with k starting at 5000s and then being reduced by the size of the new
    time slice. This guarantees that the sum of all time slices is not grater
    than 5000s.
    In each iteration, take two algorithm and substract a random number of 
    seconds from one of them and adding them to the other. Solution is kept if
    it solves more instances, else algorithm goes back to current best 
    solution.
    """
    k = 5000
    current_best={}
    assign_dict={}
    steps = 0
    current_best_solved_inst = set()
    
    # create initial solution
    for i in range(0,len(runtimes[0])):
        #assign_dict[i] = random.randint(0,k)
        assign_dict[i] = 5000 / len(runtimes[0])
        for j in range(0, len(runtimes)):
            if runtimes[j][i] < assign_dict[i]:
                current_best_solved_inst.add((j))
        k = k-assign_dict[i]
    current_best = assign_dict
    # check if initial solution is already best one
    if len(current_best_solved_inst) == len(runtimes):
        return current_best
    
    #print("initial solved: {!s}".format(len(current_best_solved_inst)))
    
    while(len(current_best_solved_inst) < len(runtimes) and steps < maxsteps):
        solved_inst = set()
        assign_dict = current_best
        
        # change time of two algorithms by taking away x sec from algo1 and adding them to algo2
        var1 = random.choice(assign_dict.keys())
        var2 = random.choice(assign_dict.keys())
        change = random.randint(0, assign_dict[var1])
        assign_dict[var1] -= change
        assign_dict[var2] += change
        
        # calculate number of solved instances
        for i in range(0,len(runtimes[0])):
            for j in range(0, len(runtimes)):
                if runtimes[j][i] < assign_dict[i]:
                    solved_inst.add((j))
        
        # compare to current best
        if len(solved_inst) >= len(current_best_solved_inst):
            current_best_solved_inst = solved_inst
            current_best = assign_dict
        if len(current_best_solved_inst) == len(runtimes[0]):
            return current_best
        steps += 1
    
    print("assignment: {!s}".format(current_best))
    if verbose:
        print("Solvable Instances: {!s}".format(len(current_best_solved_inst)))
    return current_best



def find_permutation(assignment, runtimes, maxsteps, verbose):
    """
    Random local search that finds a permutation for the algorithms.
    Solutions are compared by the number of solvable instances and the runtime 
    if first mentioned is equal. Solution returned might not be the best one, 
    depending on the value of maxsteps. 
    Initial solution: Shuffe list that contains all algorithms.
    In each iteration, take two algorithm and switch position. Solution is kept
    if it solves more instances, or if it solves the same number of instances 
    but has a lower runtime, else algorithm goes back to current best solution.
    """
    current_best = []
    permutation = []
    
    best_runtime = 0
    par10_runtime = 0
    best_solved = set()
    
    # find random initial solution
    for i in range(0,len(runtimes[0])):
        permutation.append(i)
    random.shuffle(permutation)

    #print("initial: {!s}".format(permutation))
    
    # calculate number of solved instances and runtime as initial current best
    for j in range(0,len(runtimes)):                # instances
        for i in range(0,len(runtimes[0])):         # algorithms
            if runtimes[j][i] <= assignment[permutation[i]]:
                best_runtime += runtimes[j][i]
                best_solved.add((j))
                break
            else:
                best_runtime += assignment[permutation[i]]
    
    current_best = permutation
    #print("initial solved: {!s}".format(len(best_solved)))
    steps = 0
    
    while(len(best_solved)< len(runtimes) and steps < maxsteps):
        
        permutation = current_best
        #switch places of two algorithm
        var1 = permutation.index(random.choice(permutation))
        var2 = permutation.index(random.choice(permutation))
        tmp = permutation[var2]
        permutation[var2] = permutation[var1]
        permutation[var1] = tmp
        
        cur_runtime = 0
        cur_par10_runtime = 0
        cur_solved = set()
        
        # calculate number of solved instances and runtime
        for j in range(0, len(runtimes)):           # instances
            cur_time = 0
            for i in range(0, len(runtimes[0])):    # algorithms
                if runtimes[j][i] <= assignment[permutation[i]]:
                    cur_runtime += runtimes[j][i]
                    cur_time += runtimes[j][i]
                    cur_solved.add((j))
                    break
                else:
                    cur_runtime += assignment[permutation[i]]
                    cur_time += assignment[permutation[i]]
            if i not in cur_solved:
                cur_par10_runtime += 10*5000
            else:
                cur_par10_runtime += cur_time
        
        # compare to current best solution
        if len(cur_solved) > len(best_solved):      # higher number of solved instances
            current_best = permutation
            best_solved = cur_solved
            best_runtime = cur_runtime
            par10_runtime = cur_par10_runtime
        elif len(cur_solved) == len(best_solved):   # same number of solved instances - compare runtime
            if cur_runtime <= best_runtime:
                current_best = permutation
                best_solved = cur_solved
                best_runtime = cur_runtime
                par10_runtime = cur_par10_runtime
        
        steps += 1
    
    print("permutation: {!s}".format(current_best))
    if verbose:
        print("Average runtime: {!s}".format(best_runtime / len(runtimes)))
        print("PAR10 runtime: {!s}".format(par10_runtime  / len(runtimes)))
        print("Number of instances solved: {!s}".format(len(best_solved)))
        print("Timeouts: {!s}".format(len(runtimes)-len(best_solved)))


def count_timeouts_of_single_best(data):
    """
    Counts the timeouts of the single best algorithm for comparing with the
    schedule.
    """
    single_best = aslib_stats.calculate_single_best(copy.copy(data), False)[0]
    timeouts = 0
    for line in data:
        if single_best in line[2]:
            if "timeout" in line[4]:
                timeouts += 1
    return timeouts


def find_amount_of_algorithms(data):
    """
    Goes through data and counts the different algorithm by creating a 
    dictionary with each algorithm as a key. The values are the numbers with 
    which each algorithm is represented in the other functions and in which 
    column in the matrix.
    """
    data_copy = copy.copy(data)
    algo_dict = {}
    name = ""
    i = 0
    while not (name in algo_dict.keys()):
        if name !="":
            #print(name)
            algo_dict[name] = i
            i += 1
            #print(algo_dict)
        line = data_copy.pop(0)
        name = line[2]
    return algo_dict
    

def find_amount_of_instances(data):
    """
    Goes through data and counts the different instances by creating a 
    dictionary with each instance as a key. The values are the numbers with 
    which each instance is represented in the other functions and in which 
    row in the matrix.
    """
    data_copy = copy.copy(data)
    instance_dict = {}
    i = 0
    while len(data_copy) != 0:
        line = data_copy.pop(0)
        if line[0] not in instance_dict.keys():
            #print(name)
            instance_dict[line[0]] = i
            i += 1
            #print(algo_dict)
        
    return instance_dict



if __name__=="__main__":
    main(sys.argv)
    
