# -*- coding: utf-8 -*-
"""
Created on Sun Jan 17 12:55:16 2016

@author: Saskia
"""
import arff
import sys
import copy



def main(args):
    algoruns_index = args.index("--algoruns")
    data = read_files(args[algoruns_index + 1])
    verbose = False
    if "--verbose" in args:
        verbose = True
    #data = read_files("as_exercise6/SAT11-RAND/algorithm_runs.arff")
    single_best = calculate_single_best(data, verbose)
    oracle = calculate_oracle(data, verbose)
    print_output(single_best, oracle, verbose)


def read_files(filename):
    """
    Function that is just there to read the given file and computes the data 
    part into a list.
    """
    data = arff.load(open(filename))
    raw_data = data["data"]
    return raw_data

def calculate_single_best(data, verbose):
    """
    Calculate the average runtime of all algorithms and compare them. The one
    with the smallest average runtime is the single best.
    """
    #create dictionary with all algorithms to save runtimes
    algo_dict = find_amount_of_algorithms(data)
    number_instances = len(find_amount_of_instances(data))
    
    data_copy = copy.copy(data)    
    
    while(len(data_copy)!=0):
        line = data_copy.pop(0)
        #add runtime to value of corresponding algorithm
        algo_dict[line[2]] += line[3]

    algo_dict.items()
    single_best = min(algo_dict.items(), key=lambda x: x[1])
    if verbose:
        print("SINGLE BEST:")
        print("Single best :{!s} with an average runtime of {!s}sec".format(single_best[0], single_best[1]/number_instances))
    
    #calculate PAT10    
    performance = 0
    for line in data:
        if line[2] == single_best[0]:
            if "timeout" in line[4]:
                performance += line[3]*10
            else:
                performance += line[3]
    
    return tuple((single_best[0], performance / number_instances))
    
    
def calculate_oracle(data, verbose):
    """
    Calculate for each instance which algorithm performs best. Save all best 
    algorithm in intern dictionary which can be seen on console if verbose is 
    set to true. Due to lazyness the timeouts are already set to PAR10.
    """
    data_copy = copy.copy(data)
    algo_dict = find_amount_of_algorithms(data)
    instance_dict = find_amount_of_instances(data)

    while(len(data_copy) !=0):
        line = None
        
        # for each instance find best algorithm
        for i in range(0,len(algo_dict)):
            line = data_copy.pop(0)
            if "timeout" in line[4]:
                algo_dict[line[2]] = line[3] * 10       # already PAR10
            else:
                algo_dict[line[2]] = line[3]
        best = min(algo_dict.items(), key=lambda x: x[1])
        instance_dict[line[0]] = best
        
    if verbose:
        print("ORACLE:")
        print("The following shows for each instance which algorithm performs best:")
        for key in instance_dict.keys():
            print("Instance: {!s}".format(key))
            print("Best algorithm: {!s}".format(instance_dict[key][0]))
            print("with a runtime of {!s}sec".format(instance_dict[key][1]))
            
    performance = 0
    
    # calculate PAR10 performance
    for key in instance_dict:
        performance += instance_dict[key][1]
    return performance / len(instance_dict)


def find_amount_of_algorithms(data):
    """
    Goes through data and counts the different algorithm by creating a 
    dictionary with each algorithm as a key. The values are empty, as the 
    dictionary is used for later functions.
    """
    data_copy = copy.copy(data)
    algo_dict = {}
    name = ""
    #i = 0
    while not (name in algo_dict.keys()):
        if name !="":
            #print(name)
            algo_dict[name] = 0
            #i += 1
            #print(algo_dict)
        line = data_copy.pop(0)
        name = line[2]
    return algo_dict
    

def find_amount_of_instances(data):
    """
    Goes through data and counts the different instances by creating a 
    dictionary with each instance as a key. The values are empty, as the 
    dictionary is used for later functions.
    """
    instance_dict = {}
    for line in data:
        #print(line[0])
        if line[0] not in instance_dict.keys():
            instance_dict[line[0]] = 0
    return instance_dict


def print_output(single_best, oracle, verbose):
    """
    Only there in case verbose is set to true, that the final results are 
    printed last.
    """
    if verbose:
        print("FINAL RESULTS:")

    print("Oracle : {!s}".format(oracle))
    print("SB : {!s}".format(single_best[1]))


if __name__=="__main__":
    main(sys.argv)
    	#main()