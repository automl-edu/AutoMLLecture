# -*- coding: utf-8 -*-
"""
Created on Mon Dec 28 10:47:11 2015

@author: torstenk91
"""
import argparse
import arff
import numpy as np

def parseCMD():
    """
    Parse the command line.
    """
    parser = argparse.ArgumentParser()

    defaultAlgoruns = 'as_exercise6/SAT11-RAND/algorithm_runs.arff'
    parser.add_argument('--algoruns',default=defaultAlgoruns)
    arguments = vars(parser.parse_args())
    
    return arguments

def par10(row):
    """
    Calculate the par10 performance of a given run.
    """
    if(row.runstatus == 'ok'):
        return row.runtime
    if(row.runstatus == 'timeout'):
        return row.runtime * 10
    else:
        raise ValueError('Status of instance run neither ok nor timeout!')  
arguments = parseCMD()
path = arguments['algoruns']

## load the scenario file
scenarioList = list(arff.load(path))

#get instance ids
instance_ids = np.unique([row.instance_id for row in scenarioList])
#get algoriothm list
algorithms = [row.algorithm for row in scenarioList]

    
##compute SB
n_algorithms = len(algorithms)
algo_perf = np.zeros((n_algorithms,1))
i = 0;
for algo in algorithms:
    algo_perf[i] = sum([par10(row) for row in scenarioList if row.algorithm == algo])
    i += 1      
SB = min(algo_perf)

##compute oracle
Oracle = 0;
for instance_id in instance_ids:
    Oracle += min([par10(row) for row in scenarioList if row.instance_id == instance_id])
    
#print results    
print("Oracle: {}".format(Oracle/len(instance_ids)))
print("SB: {}".format(SB/len(instance_ids)))
