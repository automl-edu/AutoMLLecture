# -*- coding: utf-8 -*-
"""
Created on Tue Dec 29 16:28:21 2015

@author: torstenk91
"""

import numpy as np
import argparse
import pysmac
import operator
from sklearn.preprocessing import Imputer,MinMaxScaler
import arff
from sklearn.pipeline import Pipeline
from sklearn import linear_model,ensemble,svm


def parseCMD():
    """
    Parse the command line.
    """
    parser = argparse.ArgumentParser()

    defaultAlgoruns = 'as_exercise6/SAT11-RAND/algorithm_runs.arff'
    defaultFeatures = 'as_exercise6/SAT11-RAND/feature_values.arff'
    defaultCV = 'as_exercise6/SAT11-RAND/cv.arff'

    parser.add_argument('--algoruns',default=defaultAlgoruns)
    parser.add_argument('--features',default=defaultFeatures)
    parser.add_argument('--cv',default=defaultCV)
    parser.add_argument('--timeout',default = 5000)
    parser.add_argument('--method',default = 1)
    parser.add_argument('--verbose',default=False,action='store_true')
    
    arguments = vars(parser.parse_args())
    
    return arguments

## 
def getFoldIds(): 
    """
    Load the cv file and generate n_folds x n_train and
    n_folds x n_test arrays containing the instance_ids of the folds.
    """
    cvs = list(arff.load(path_cv))
    folds = [row.fold for row in cvs]
    n_folds = np.int( max(folds))
    
    IDX_TRAIN = [list([]) for _ in range(n_folds)]
    IDX_TEST = [list([]) for _ in range(n_folds)]
    for item in cvs:
        k = np.int(item.fold)
        instance_id = item.instance_id
        IDX_TEST[k-1].append(instance_id)
        for idx in range(n_folds):
            if not (idx == k-1):
                IDX_TRAIN[idx].append(instance_id)
    return (IDX_TRAIN,IDX_TEST)

def parseFeatureVals(path, split =','):
    """
    Parse the arff file file into a nInstances x nFeatures array. 
    """
    beginParse = False
    features = []
    for line in open(path):
        if '@DATA' in line:
            beginParse = True;
        if(beginParse):
            features.append(np.array(line.split(split)))
    return features  
    
##       
def getXYForAlgorithm(algo_id, instance_ids):
    """
    Get the nData x nFeatures , nData x 1 X and Y data for a given
    algorithm id and list of instance ids. 
    """
    algoruns = list(arff.load(path_algoruns))
    algorows = [row for row in algoruns if row.algorithm == algo_id] #get the rows in algoruns for the given algo_id
    featurevals = parseFeatureVals(path_featurevals) #parse the feature_vals.arff file 
    X = []
    # get the features for the instance_id in the same order as the Y values
    for row in algorows:
        if(row.instance_id in instance_ids):
            X.append(getFeaturesForInstanceId(row.instance_id,featurevals))     
    # Get the y values for the given algo_id, instance , if the instance_id is contained in the list of instance_ids    
    Y = [row.runtime for row in algorows if row.instance_id in instance_ids] 
        
    return X,Y

## 
def getFeaturesForInstanceId(instance_id,feature_values,deleteId = True,replace_missing = True):
    """
    Get the featues for a given instance_id, where feature_values
    is the parsed feature file (see parseFeatureVals()).
    """
    for row in feature_values:
        if(instance_id in row[0]):
            vec = np.asarray(row)
            if deleteId:
                vec = vec[1:-1]
            if replace_missing:
                vec = replaceMissingFeature(vec)
            return vec    
## 
def getCrossValData(algo_id):
    """
    Get the data x_train,y_train,x_test,y_test for all folds for one algorithm.
    """
    IDX_TRAIN,IDX_TEST = getFoldIds()
    X_TRAIN = []
    Y_TRAIN = []
    X_TEST = []
    Y_TEST = [] 
    for idx_train in IDX_TRAIN:
        x_train,y_train = getXYForAlgorithm(algo_id,idx_train)
        X_TRAIN.append(np.matrix(x_train))
        Y_TRAIN.append(np.array(y_train))
    for idx_test in IDX_TEST:
        x_test,y_test = getXYForAlgorithm(algo_id,idx_test)
        X_TEST.append(np.matrix(x_test))        
        Y_TEST.append(np.array(y_test))
    return (X_TRAIN,Y_TRAIN,X_TEST,Y_TEST)

def getPairwiseCrossValData(algo_id1,algo_id2):
    """
    Get the data x_train,y_train,x_test,y_test for all folds for one algorithm.
    """
    IDX_TRAIN,IDX_TEST = getFoldIds()
    X_TRAIN = []
    Y_TRAIN = []
    X_TEST = []
    Y_TEST = [] 
    Y_TRAIN_WEIGHTS = []
    for idx_train in IDX_TRAIN:
        x_train,y_train = getXYPerfDifference(algo_id1,algo_id2,idx_train)
        X_TRAIN.append(np.matrix(x_train))
        y_train = np.where(y_train == 0, 50,y_train)
        Y_TRAIN_WEIGHTS.append(1/np.abs(np.array(y_train)))
        Y_TRAIN.append(np.where(y_train > 0 ,1,0))
        
    for idx_test in IDX_TEST:
        x_test,y_test = getXYPerfDifference(algo_id1,algo_id2,idx_test)
        X_TEST.append(np.matrix(x_test))        
        Y_TEST.append(np.where(y_test > 0,1,0))
        
    #print(Y_TRAIN[0])    
    #print(Y_TRAIN_WEIGHTS[0])
    return (X_TRAIN,Y_TRAIN,Y_TRAIN_WEIGHTS,X_TEST,Y_TEST)

def getXYPerfDifference(algo_id1,algo_id2, instance_ids):
    """
    Get the nData x nFeatures , nData x 1 X and Y data for a given
    algorithm id and list of instance ids. 
    """
    algoruns = list(arff.load(path_algoruns))
    algorows1 = [row for row in algoruns if row.algorithm == algo_id1] #get the rows in algoruns for the given algo_id
    algorows2 = [row for row in algoruns if row.algorithm == algo_id2]    
    
    featurevals = parseFeatureVals(path_featurevals) #parse the feature_vals.arff file 
    X = []
    # get the features for the instance_id in the same order as the Y values
    for row in algorows1:
        if(row.instance_id in instance_ids):
            X.append(getFeaturesForInstanceId(row.instance_id,featurevals))     
    # Get the y values for the given algo_id, instance , if the instance_id is contained in the list of instance_ids    
    Y_1 = [row.runtime for row in algorows1 if row.instance_id in instance_ids] 
    Y_2 = [row.runtime for row in algorows2 if row.instance_id in instance_ids]
    #print(Y_1)
    #print(Y_2)
    Y = np.array(Y_1) - np.array(Y_2)    
    return X,Y

        
def par10(row):
    """
    Calculate the par10 performance of a given run
    """
    if(row.runstatus == 'ok'):
        return row.runtime
    if(row.runstatus == 'timeout'):
        return row.runtime * 10
    else:
        raise ValueError('Status of instance run neither ok nor timeout!')

def getAlgoIds():
    """
    get a list of algorithm_ids for the given problem
    """
    algoruns = list(arff.load(path_algoruns))
    algo_ids = []
    for row in algoruns:
        algo_ids.append(row.algorithm)
    algo_ids = np.unique(algo_ids)
    return algo_ids    
    
def getInstanceIds():
    """
    get a list of instance_ids for the given problem
    """
    algoruns = list(arff.load(path_algoruns))
    instance_ids = []
    for row in algoruns:
        instance_ids.append(row.instance_id)
    instance_ids = np.unique(instance_ids)
    return instance_ids    
    
def prod(factors):
    return reduce(operator.mul, factors, 1)
    
def replaceMissingFeature(feature_vector, missing_value = '?'):
    """
    replace the missing values in an array with np.nan in order to 
    convert array to float. Return converted array
    """
    for k in range(len(feature_vector)):
        #print(item)
        if missing_value == feature_vector[k]:
            feature_vector[k] = np.nan
    return np.array(feature_vector,dtype="float")        

def crossvalScore(predictor,X_TRAIN,Y_TRAIN,X_TEST,Y_TEST,sample_weights = None):
    """
    return the crossvalidation score of a predictor given all folds (train,test)
    """
    nFolds = len(X_TRAIN)
    score = 0;
    for k in range(nFolds):
        
        if sample_weights is None:
            predictor.fit(X_TRAIN[k],Y_TRAIN[k])
        else:
            predictor.fit(X_TRAIN[k],Y_TRAIN[k], predictor__sample_weight = sample_weights[k])
        score += predictor.score(X_TEST[k],Y_TEST[k])
    return score/nFolds
 
def eval_smac_choose_regressor(regressor, # which regressor to use
                #gp_kernel = None, 
                #gp_regr = None,
                rf_n_estimators = None, 
                rf_max_features = None,
                rf_max_depth = None,
                # the ones for k-nearest-neighbors
                ridge_alpha=None,
                do_minmax = None,
                imput_strategy = None):
    """
    The function to be minimized by SMAC. 
    """
    imputer = Imputer(missing_values = 'NaN',strategy = imput_strategy)
                        
    #if regressor == 'gaussian_process':
    #    predictor = gaussian_process.GaussianProcess(regr=gp_regr,corr=gp_kernel)
    if regressor == 'ridge_regression':    
        predictor = linear_model.Ridge(alpha = ridge_alpha)
    elif regressor == 'random_forest':
        predictor = ensemble.RandomForestRegressor(n_estimators = rf_n_estimators, 
                                                   max_features = rf_max_features, 
                                                   max_depth = rf_max_depth)      
    if(do_minmax == "True"):
        pipeline = Pipeline(steps=[("imputer",imputer),("minmax",MinMaxScaler()),("predictor",predictor)])
    else:
        pipeline = Pipeline(steps=[("imputer",imputer),("predictor",predictor)])
    
    return -crossvalScore(pipeline,X_train,Y_train,X_test,Y_test)

def smac_choose_regressor(regressor, # which regressor to use
                #gp_kernel = None, 
                #gp_regr = None,
                rf_n_estimators = None, 
                rf_max_features = None,
                rf_max_depth = None,
                # the ones for k-nearest-neighbors
                ridge_alpha=None,
                do_minmax = None,
                imput_strategy = None):
    """
    Return the regressor based on the parameters found be SMAC. 
    """
    imputer = Imputer(missing_values = 'NaN',strategy = imput_strategy)
                                         
    #if regressor == 'gaussian_process':
    #    predictor = gaussian_process.GaussianProcess(regr=gp_regr,corr=gp_kernel)
    if regressor == 'ridge_regression':    
        predictor = linear_model.Ridge(alpha = ridge_alpha)
    elif regressor == 'random_forest':
        predictor = ensemble.RandomForestRegressor(n_estimators = rf_n_estimators, 
                                                   max_features = rf_max_features, 
                                                   max_depth = rf_max_depth)      
    if(do_minmax == "True"):
        pipeline = Pipeline(steps=[("imputer",imputer),("minmax",MinMaxScaler()),("predictor",predictor)])
    else:
        pipeline = Pipeline(steps=[("imputer",imputer),("predictor",predictor)])
    
    return pipeline

def eval_smac_choose_classifier( # which classifier to use
				# parameters for the tree based classifiers
                trees_n_estimators = None, trees_criterion = None, 
                trees_max_features = None, trees_max_depth = None,
                imput_strategy = None):
                # the ones for k-nearest-neighbors):
				#note that possibly inactive variables have to be optional
				#as pySMAC does not assign a value for inactive variables
				#during the minimization pha
    imputer = Imputer(missing_values = 'NaN',strategy = imput_strategy)     
                  
    predictor = ensemble.RandomForestClassifier(
						trees_n_estimators, trees_criterion,
						trees_max_features, trees_max_depth)          
    pipeline = Pipeline(steps=[("imputer",imputer),("predictor",predictor)]) 
    
    return -crossvalScore(pipeline,X_train,Y_train,X_test,Y_test,sample_weights = weights)
    
parameter_definition_classification=dict(\
     imput_strategy = ("ordinal",['mean','median','most_frequent'],'mean'),
	trees_max_depth =  ("integer", [1,15],  8),
	trees_max_features=("integer", [1,30], 5),
	trees_n_estimators=("integer", [1,100],10 ,'log'),          
	trees_criterion =("categorical", ['gini', 'entropy'], 'entropy'),
	# Usually you would make this a categorical, but to showcase all 
	# conditional clauses, let's pretend it's an ordinal parameter,
	# so we can use > and <.
	)

def smac_choose_classifier(trees_n_estimators = None, trees_criterion = None,
                           trees_max_features = None, trees_max_depth = None,
                           imput_strategy = None):
       
       predictor = ensemble.RandomForestClassifier(n_estimators = trees_n_estimators,
                                              criterion = trees_criterion,
                                              max_features = trees_max_features,
                                              max_depth = trees_max_depth)
       imputer = Imputer(missing_values = 'NaN',strategy = imput_strategy)     
       pipeline = Pipeline(steps=[("imputer",imputer),("predictor",predictor)])
       return pipeline                        
                               
 
def parse_smac_regression_results(parameters):
    """
    Parsing the smac regressor results to get the parameters in the right order.
    """
    result_parameters = []
    result_parameters.append(parameters['regressor'])
    result_parameters.append(int(parameters['rf_n_estimators']))
    result_parameters.append(int(parameters['rf_max_features']))
    result_parameters.append(int(parameters['rf_max_depth']))
    result_parameters.append(float(parameters['ridge_alpha']))
    result_parameters.append(parameters['do_minmax'])
    result_parameters.append(parameters['imput_strategy'])
    return result_parameters 
    
def parse_smac_classification_results(parameters):
    """
    Parsing the smac classifier results to get the parameters in the right order.
    """
    result_parameters = []
    result_parameters.append(int(parameters['trees_n_estimators']))
    result_parameters.append(parameters['trees_criterion'])
    result_parameters.append(int(parameters['trees_max_features']))
    result_parameters.append(int(parameters['trees_max_depth']))
    result_parameters.append(parameters['imput_strategy'])
 
    return result_parameters     
# defining all the parameters with respective defaults.
parameter_definition_regression=dict(\
	imput_strategy = ("ordinal",['mean','median','most_frequent'],'mean'),
	do_minmax=("ordinal",["True","False"],"True"),          
	#kernel_ridge_alpha = ("real", [1e-10,1e2], 1e-1),
	 ridge_alpha = ("real", [1e-10,1e2], 1e-1),
      rf_n_estimators = ("integer",[1,50],10),
      rf_max_features = ("integer",[1,100],8),
      rf_max_depth = ("integer",[1,100],30),   
    	#gp_regr = ("ordinal",['constant','linear','quadratic'],'constant'),
     #gp_kernel = ("ordinal",['absolute_exponential','generalized_exponential','cubic','linear'],"absolute_exponential"),
	regressor  = ("categorical", ['ridge_regression','random_forest' ], 'ridge_regression')
	# Usually you would make this a categorical, but to showcase all 
	# conditional clauses, let's pretend it's an ordinal parameter,
	# so we can use > and <.
	)

# definition of condition values
conditionals_regression = [ #'gp_kernel    | regressor == gaussian_process',
                 #'gp_regr    | regressor == gaussian_process',
                 'ridge_alpha        | regressor == ridge_regression',                 
                 'rf_n_estimators    | regressor == random_forest',
                 'rf_max_features    | regressor == random_forest',
                 'rf_max_depth    | regressor == random_forest',                 
                 #'kernel_ridge_alpha | regressor == kernel_ridge'
                ]

#parse commandline
arguments = parseCMD()
path_algoruns = arguments['algoruns']
path_featurevals = arguments['features']
path_cv = arguments['cv']
timeout = arguments['timeout']
method = int(arguments['method'])
verbose = arguments['verbose']

"""
Build a regression model for each algorithm to predict runtime and choose
the algorithm with the lowest predicted runtime for each instance.

Apply SMAC to each algorithm to choose a runtime prediction model.
Predict the run-time of an instance with each algorithm (use the folds as training
in which the given instance is not present) and choose the one with the lowest
predicted runtime
"""
if method == 1:
    ## Run SMAC to find a EPM for each algorithm      
    algo_ids = getAlgoIds()  #get the list of algorithms
    regressors = []
    for algo_id in algo_ids:
        #prepare pysmac    
        if verbose:
            print("Running SMAC to optimize regression-model for algorithm: {}".format(algo_id))
        opt = pysmac.SMAC_optimizer( debug = 0,
    							 working_directory = '/tmp/pySMAC_test/', persistent_files=True, t_limit_total_s=200 )
        X_train,Y_train,X_test,Y_test = getCrossValData(algo_id)
        # optimize regressors using smac
        value,parameters = opt.minimize(eval_smac_choose_regressor,15, parameter_definition_regression,
                                        conditional_clauses = conditionals_regression)                            
        regressors.append(smac_choose_regressor(*parse_smac_regression_results(parameters)))
        if verbose:
            print("Obtained parameters: {}, with score: {}".format(parameters,-value))
    ## Train the regressors and predict runtime on every fold and predict the test fold instances.
    IDX_Train, IDX_Test = getFoldIds()
    #X_train,Y_train,X_test,Y_test = 
    
    nFolds = len(IDX_Train)
    nAlgos = len(algo_ids)
    #instances = []
    algo_instances = [list([]) for _ in range(nAlgos)]  
    algo_ids_res = []
    n_instances = 0
    # Apply smac-optimized regressors to the folds
    for k in range(nFolds):
        n_instances_fold = len(IDX_Test[k])
        prediction = np.zeros((nAlgos,n_instances_fold))
        for l in range(nAlgos): #predict runtime for every algorithm
            X_train,Y_train,X_test,Y_test = getCrossValData(algo_ids[l])
            regressors[l].fit(X_train[k],Y_train[k])
            prediction[l,:] = regressors[l].predict(X_test[k])
        instance_ids_fold = IDX_Test[k]    
        for ii in range(n_instances_fold):
            algo_id = np.argmin(prediction[:,ii]) #take the algorithm with lowest predicted runtime
            algo_ids_res.append(algo_id)
            algo_instances[algo_id].append(IDX_Test[k][ii])
            n_instances += 1
    
    #calculate par10 performance
    algoruns = list(arff.load(path_algoruns))
    runtime_total = 0
    for k in range(nAlgos):
        for row in algoruns:
            if(row.algorithm == algo_ids[k]):
                instance_id = row.instance_id
                if(instance_id in algo_instances[k]):
                    runtime_total += par10(row)
    if verbose:    
        print("Average par10-runtime on all instances with selected algorithms: {}".format(runtime_total/n_instances))     
    else:
        print("PAR10 performance: {}".format(runtime_total/n_instances))
    # print selection choices    
    print("Selection per instance:")    
    for ii in range(nAlgos):    
        for instance_id in algo_instances[algo_id]:
            print("{} : {}".format(instance_id,algo_ids[ii]))
            
"""
Train cost-sensitive pairwise random forest classifier.

"""
if method == 2:
    print("WARNING: this is going to take a while and won't work really well!")
    algo_ids = getAlgoIds()
    #classifiers = []
    classifiers = {}
    for ii in range(len(algo_ids)):
        for jj in range(ii+1,len(algo_ids)):
            if verbose:
                print("Applying SMAC to optimize classifier for algorithm pair: {} <-> {}".format(algo_ids[ii],algo_ids[jj]))
            opt = pysmac.SMAC_optimizer( debug = 0,
    							 working_directory = '/tmp/pySMAC_test/', persistent_files=True, t_limit_total_s=200 )
            X_train,Y_train,weights,X_test,Y_test = getPairwiseCrossValData(algo_ids[ii],algo_ids[jj])
            
            # optimize pairs of classifier using SMAC
            value,parameters = opt.minimize(eval_smac_choose_classifier,10, parameter_definition_classification)     
            classifiers[algo_ids[ii]+algo_ids[jj]] = smac_choose_classifier(*parse_smac_classification_results(parameters)) 
            classifiers[algo_ids[ii]+algo_ids[jj]] = smac_choose_classifier(*parse_smac_classification_results(parameters))
            if verbose:
                print("Obtained parameters: {}, with score: {}".format(parameters,-value))

    IDX_Train, IDX_Test = getFoldIds()
    nFolds = len(IDX_Train)
    nAlgos = len(algo_ids)
    n_instances = 0
    algo_ids_res = []
    algo_instances = [list([]) for _ in range(nAlgos)] 
    #train obtained classifiers on the folds
    for k in range (nFolds):
        n_instances_fold = len(IDX_Test[k])
        votes = np.zeros((n_instances_fold,nAlgos))
        for ii in range(nAlgos):
            for jj in range(ii+1,nAlgos):
                X_train,Y_train,weights,X_test,Y_test = getPairwiseCrossValData(algo_ids[ii],algo_ids[jj])
                classifier = classifiers[algo_ids[ii]+algo_ids[jj]]
                classifier.fit(X_train[k],Y_train[k],predictor__sample_weight=weights[k]) 
                prediction_fold = classifier.predict(X_test[k])
                votes[:,ii] += prediction_fold
                votes[:,jj] += np.abs(-prediction_fold)
        for ll in range(n_instances_fold):
            algo_id = np.argmax(votes[ll,:]) #Take the algorithm with most votes
            algo_ids_res.append(algo_id)
            algo_instances[algo_id].append(IDX_Test[k][ll])
            n_instances += 1
            
    algoruns = list(arff.load(path_algoruns))
    runtime_total = 0
    #calculate par10 performance
    for k in range(nAlgos):
        for instance in algo_instances[k]:
            runtime_total += sum([par10(row) for row in algoruns if (row.algorithm == algo_ids[k] and row.instance_id == instance)])
    if verbose:    
        print("Average par10-runtime on all instances with selected algorithms: {}".format(runtime_total/n_instances)) 
    else:
        print("PAR10 performance: {}".format(runtime_total/n_instances))
    print("Selection per instance:")    
    # print selection choices
    for ii in range(nAlgos):    
        for instance_id in algo_instances[algo_id]:
            print("{} : {}".format(instance_id,algo_ids[ii]))
