import arff, numpy as np
import sys
import random
import multiprocessing
from multiprocessing import Process
import json

def evaluate(schedule):
    c=0
    for i in range(len(instances)):
        solved=max(times[:,i]<=schedule)
        if solved:
            c+=1
    return c
  
def evaluate_list(schedule_list):
    result=list()
    for s in schedule_list:
        result.append(evaluate(s))
    return result

def get_rand_schedule(size):
    result = np.zeros(size)
    for i in range(max_timeslots):
        result[random.randrange(size)]+=1
    return result

def getNeighborhood(schedule,m):
    neighbors=list()
    for i in range(len(schedule)):
        for j in range(len(schedule)):
            if j!=i and schedule[i]>=m and schedule[j]<=max_timeslots-m:
                nb=schedule.copy()
                nb[i]-=m
                nb[j]+=m
                neighbors.append(nb)
    return neighbors

def getNeighborhood_permutation(perm):
    neighbors=list()
    for i in range(len(perm)):
        for j in range(len(perm)):
            if j!=i:
                nb=perm.copy()
                help=nb[i]
                nb[i]=nb[j]
                nb[j]=help
                neighbors.append(nb)
    return neighbors

def hash(schedule):
    result = 0
    for i in range(len(schedule)):
        result+=i*(max_timeslots+1)*schedule[i]
    return result

def evaluate_permutation(schedule, perm):
    time_sum=0
        
    for inst in range(len(instances)):
        time=0
        k=0
        solved=False
        while k<len(perm) and time<max_timeslots and not solved:
            solved = (schedule[perm[k]]>=times[perm[k],inst])
            if solved:
                time+=times[perm[k], inst]
            else:
                time+=schedule[perm[k]]
            #DEBUG OUTPUT print("{}\t{}\t{}\t{}\t{}".format(k,solved,time,schedule[perm[k]],times[perm[k],inst]))
            k+=1
        time_sum += min(max_timeslots, time)

    return -time_sum/len(instances)
    
def evaluate_list_permutation(schedule, perm_list):
    result=list()
    for perm in perm_list:
        result.append(evaluate_permutation(schedule, perm))
    return result


def RII_permutation(schedule, result_queue=None, maxSteps=50, wp=0.05):
    s_candidate=np.random.permutation(len(schedule))
    steps=0
    tabuList=list()
    tabuList.append(hash(s_candidate))
    finished=False
    while (steps<maxSteps or maxSteps<=0) and not finished:
        neighbors=np.array(getNeighborhood_permutation(s_candidate))
        evaluation=np.array(evaluate_list_permutation(schedule, neighbors))
        best_neighbor=neighbors[np.argmax(evaluation),:]
        current_evaluation=evaluate_permutation(schedule, s_candidate)
        best_neighbor_evaluation=evaluate_permutation(schedule, best_neighbor)
 #       print("{}  --> {}  {}".format(current_evaluation, best_neighbor_evaluation, s_candidate[0:8]))
        if random.random() <= wp: ## random neighbor selection with probability wp
            rand_idx = random.randint(0,len(neighbors)-1)
            s_candidate=neighbors[rand_idx,:]
        else: ## otherwise chose neighbor s' of s with g(s') < g(s)
            betterIndexes=np.nonzero(evaluation>current_evaluation)[0] #betterIndexes=[x for x in range(len(evaluation)) if evaluation[x]>=current_evaluation]
            if (len(betterIndexes)>0):
                randIndex=np.random.randint(len(betterIndexes))
                idx = betterIndexes[randIndex]
                s_candidate=neighbors[idx,:]
            else:
                #equalIndexes=[x for x in range(len(evaluation)) if evaluation[x]>=current_evaluation]
                if hash(best_neighbor) not in tabuList:  ## if no such neighbor exists, choose s' s.t. g(s') minimal
                    s_candidate=best_neighbor
                else:
                    ## best neighbor in tabu list
                    finished=True
                    
        steps+=1
        tabuList.append(hash(s_candidate))
    if result_queue!=None:
        result_queue.put(s_candidate)
    return s_candidate


def RII_schedule(result_queue=None, maxSteps=50, wp=0.05):
    ## create random init solution candidate:
    s_candidate=np.zeros(len(algorithms))
    s_candidate[0]=max_timeslots
    #s_candidate=get_rand_schedule(len(algorithms))
    
    tabuList=list()
    steps=0
    neighbor_stepwidth=max_timeslots #this variable determines how much the neighbors should differ from the original schedule
    finished=False
    
    while (steps<maxSteps or maxSteps<=0) and not finished:
        neighbors=np.array(getNeighborhood(s_candidate,neighbor_stepwidth))
        evaluation=np.array(evaluate_list(neighbors))
        best_neighbor=neighbors[np.argmax(evaluation),:]
        current_evaluation=evaluate(s_candidate)
        best_neighbor_evaluation=evaluate(best_neighbor)
#        print("{}  --> {}  {}".format(current_evaluation, best_neighbor_evaluation, s_candidate[0:8]))
        if random.random() <= wp: ## random neighbor selection with probability wp
            rand_idx = random.randint(0,len(neighbors)-1)
            s_candidate=neighbors[rand_idx,:]
        else: ## otherwise chose neighbor s' of s with g(s') < g(s)
            betterIndexes=np.nonzero(evaluation>current_evaluation)[0] #betterIndexes=[x for x in range(len(evaluation)) if evaluation[x]>=current_evaluation]
            if (len(betterIndexes)>0):
                randIndex=np.random.randint(len(betterIndexes))
                idx = betterIndexes[randIndex]
                s_candidate=neighbors[idx,:]
            else:
                if hash(best_neighbor) not in tabuList:  ## if no such neighbor exists, choose s' s.t. g(s') minimal
                    s_candidate=best_neighbor
                else:
                    ## best neighbor in tabu list
                    neighbor_stepwidth=neighbor_stepwidth//2
#                    print(neighbor_stepwidth)
                    finished = (neighbor_stepwidth==0)
        steps+=1
        tabuList.append(hash(s_candidate))
    if result_queue!=None:
        result_queue.put(s_candidate)
    return s_candidate

def print_permutation(perm):
    permstring=""
    for i in perm:
        permstring+="\""+num2alg[i]+"\", "
    print("permutation: ["+permstring[:-2]+"]")

def print_schedule(schedule):
    assignmentstring=""
    for i in range(len(schedule)):
        assignmentstring+="\""+num2alg[i]+"\": "+str(schedule[i])+", "
    print("assignment: {"+assignmentstring[:-2]+"}")


def run_with_limited_time(func, args, kwargs, time):
    """Runs a function with time limit
    :param func: The function to run
    :param args: The functions args, given as tuple
    :param kwargs: The functions keywords, given as dict
    :param time: The time limit in seconds
    :return: True if the function ended successfully. False if it was terminated.
    """
    p = Process(target=func, args=args, kwargs=kwargs)
    p.start()
    p.join(time)
    if p.is_alive():
        p.terminate()
        return False
    return True


def percentage_without_timeout(sat_instance, solver, timeout_seconds, n=20):
    result_queue = multiprocessing.Queue()
    for i in range(n):
        run_with_limited_time(solver, (sat_instance, result_queue, -1,),{},timeout_seconds)
    success=0
    while not result_queue.empty():
        r=result_queue.get()
        success+=r!=None
    return 1.0*success/n

def start_optimizing():
    #find schedule
    max_seconds_schedule=200
    max_seconds_permutation=70
    result_queue = multiprocessing.Queue()
    run_with_limited_time(RII_schedule, (result_queue, 100, 0.05,),{},max_seconds_schedule)
    s=result_queue.get()
    
    #find permutation
    result_queue = multiprocessing.Queue()
    run_with_limited_time(RII_permutation, (s, result_queue, 50, 0.05,),{},max_seconds_permutation)
    perm=result_queue.get()
    
    #print results
    print_schedule(s)
    print_permutation(perm)
    #print("evaluation: {}".format(-evaluate_permutation(s,perm)))

## Load and parse arff
if sys.argv.__len__() < 2:
    exit()
path=sys.argv[1]
if (path.startswith("-")):
    path=sys.argv[2]
dataset=arff.load(open(path, 'rb'))#dataset = arff.load(open('as_exercise6/SAT11-INDU/algorithm_runs.arff', 'rb'))
data = np.array(dataset['data'])
max_timeslots=4999#max_timeslots=max(data[:,3].astype(float))-1
algorithms=np.unique(data[:,2])
instances=np.unique(data[:,0])

## create mappings from algorithm (and instance) names to indices and vice verca
alg2num=dict()
i=0
for alg in algorithms:
    alg2num[alg]=i
    i+=1
num2alg={v: k for k, v in alg2num.items()}

ins2num=dict()
i=0
for inst in instances:
    ins2num[inst]=i
    i+=1
num2ins={v: k for k, v in ins2num.items()}

## calculate matrix with the runtimes for each algorithm-instance tuple
times = np.zeros((len(algorithms), len(instances)))
for alg in algorithms:
    tmp=filter(lambda x: x[2]==alg, data)
    for inst in instances:
        times[alg2num[alg],ins2num[inst]]=np.mean(np.array(filter(lambda x: x[0]==inst, tmp))[:,3].astype(np.float))
        pass


start_optimizing()

