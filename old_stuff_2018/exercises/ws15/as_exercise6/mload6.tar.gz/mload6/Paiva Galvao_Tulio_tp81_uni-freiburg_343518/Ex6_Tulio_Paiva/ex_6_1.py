import arff
import json
import os
import numpy as np
import sys
import argparse



def getDict1(data):
	"""
	It transforms the arff data in a dictionary with two keys: [instance][algorithm], which stores the corresponding runtime
	
	:param data: the loaded arff data
	:type data: dict of lists
	:return setIns: a list with all instances
	:rtype setIns: list
	:return setAlgos: a list with all algorithms
	:rtype setAlgos: list
	:return dicInsAlgo: a dictionary with two entries, one for instance, the other for algorithms, the value is a list with time and statues
	:rtype dicInsAlgo: dict of dict of list
	"""
	setIns = set()
	setAlgos = set()
	dicInsAlgo = dict()
	
	for i in xrange(len(data['data'])):
		ins = data['data'][i][0]
		setIns.add(ins)
		alg = data['data'][i][2]
		setAlgos.add(alg)
		dicAlgo = [float(data['data'][i][3]), data['data'][i][4]]
		if ins in dicInsAlgo.keys():
			dicInsAlgo[ins][alg] = dicAlgo
		else:
			dicInsAlgo[ins] = dict()
			dicInsAlgo[ins][alg] = dicAlgo
			
	
	setIns = list(setIns)
	setAlgos = list(setAlgos)
	
	return setIns, len(setIns), setAlgos, len(setAlgos), dicInsAlgo



def getOracle(np_dict):
	"""
	Calculate the oracle value
	
	:param np_dict: a two dimensional ndarray with the corresponding runtime values
	:type np_dict: ndarray
	:return: the mean value of the minima corresponding to each instance
	:rtype: float 
	"""
	mins = np.min(np_dict, axis=1)
	#if np_dict.shape[0] == mins.shape[0]:
	return np.mean(mins, axis=0)	



def getSB(np_dict):
	"""
	Calculate the Single Best value
	
	:param np_dict: a two dimensional ndarray with the corresponding runtime values
	:type np_dict: ndarray
	:return: the minimum value of the meanas corresponding to each algorithm
	:rtype: float 
	"""
	return np.min(np.mean(np_dict, axis=0))

def getNpDict(infoDict, ins_list, algo_list):
	"""
	It transform a dictionary with entries [instance][algorithm] = [runtime, status]
	into a ndarray of two dimensions, the first dimension correspondinf to the instances, 
	the second to the algorithms. The runtime is punished with 10*k, being k=5000
	
	:param infoDict: a dictionary with entries [instance][algorithm] = [runtime, status]
	:type infoDict: dict
	:param ins_list: a list of all instances
	:type ins_list: list
	:param algo_list: a list of all algorithms
	:type algo_list: list
	:return: a ndarray of two dimensions with the value equal to the punished runtime
	:rtype: ndarray
	"""
	k = 5000.
	np_dic = np.zeros((len(ins_list), len(algo_list)))
	for i in xrange(len(ins_list)):
		#print 'ins_list[i]: ', ins_list[i]
		for j in xrange(len(algo_list)):
			#print 'algo_list[j]: ', algo_list[j]
			val = infoDict[ins_list[i]][algo_list[j]][0]
			#print 'val: ', val
			if val >=k:
				np_dic[i][j] = 10*k
			else:
				np_dic[i][j] = val
	return np_dic

def getTime(infoDict, ins, alg):
	"""
	Get the runtime value for a given combination of instance and algorithm
	
	:param infoDict: a dictionary with entries [instance][algorithm] = [runtime, status]
	:type infoDict: dict
	:param ins: instance name
	:type ins: string
	:param alg: algorithm name
	:type alg: string
	:return: the corresponding runtime
	:rtype: float 
	"""
	return infoDict[ins][alg][0]

def getStatus(infoDict, ins, alg):
	"""
	Get the status for a given combination of instance and algorithm
	
	:param infoDict: a dictionary with entries [instance][algorithm] = [runtime, status]
	:type infoDict: dict
	:param ins: instance name
	:type ins: string
	:param alg: algorithm name
	:type alg: string
	:return: the corresponding status
	:rtype: string
	"""
	return infoDict[ins][alg][1]

def getInfo(infoDict, ins, alg):
	"""
	Get the runtime and status values for a given combination of instance and algorithm
	
	:param infoDict: a dictionary with entries [instance][algorithm] = [runtime, status]
	:type infoDict: dict
	:param ins: instance name
	:type ins: string
	:param alg: algorithm name
	:type alg: string
	:return: the corresponding runtime and status
	:rtype: list
	"""
	return infoDict[ins][alg]

def run(algoruns):
	"""
	Calculate the oracle and the single best value for a given algoruns file of type arff
	
	:param algoruns: name of the algoruns file of type arff
	:type algoruns: string
	"""
	with open(algoruns, 'r') as f:
		data = arff.load(f)
	
	inst, inst_nr, algo, algo_nr, infoDict  = getDict1(data)
	np_dict = getNpDict(infoDict, inst, algo)
	sb = getSB(np_dict)
	oracle = getOracle(np_dict)
	
	print 'Oracle: ', oracle
	print 'SB: ', sb
	



if __name__== "__main__":
	parser = argparse.ArgumentParser(description='Exercise Mload 6-1')
	parser.add_argument('--algoruns', type=str, default='algorithm_runs2.arff',  help='Name of the arff file')
	arg = parser.parse_args()
	run(arg.algoruns)
