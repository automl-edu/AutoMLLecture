import arff
import json
import os
import numpy as np
import sys
import argparse
from sklearn.preprocessing import Imputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn import cross_validation
from sklearn.cross_validation import KFold
from sklearn.metrics import accuracy_score

def regr_train(trainData, features):
	"""
	Train one linear ridge regression for each algorithm with training data coming from the algorithm and feature files
	
	:param targetData: the instance by algorithm table containing all runtimes
	:type targetData: ndarray
	:param features: the features corresponding to each instance
	:type features: ndarray
	:return: all trained regressors
	:rtype: list
	"""
	all_regr = list()
	nr_algo = trainData.shape[1]
	for i in xrange(nr_algo):
		clf = Ridge(intercept=False)
		clf.fit(features, np.log(trainData[:,i]).reshape(-1,1))
		#clf.fit(features, trainData[:,i].reshape(-1,1))
		all_regr.append(clf)
	return all_regr, nr_algo

def regr_pred(testData, all_regr, nr_regr):
	"""
	Predict the best algorithm for a instance based on its features. 
	
	:param testData: the features of the instance whose best algorithm is being predicted
	:type testData: ndarray
	:param all_regr: all trained regressors, one for each algorithm
	:type all_regr: list
	:param nr_regr: number of regressors
	:type nr_regr: int
	:return: the best algorithm for the given instance
	"""
	predictions = np.zeros(nr_regr)
	for i in xrange(len(all_regr)):
		predictions[i] = all_regr[i].predict(testData)

	
	bestAlgo = np.argmin(predictions, axis=0) + 1
	return bestAlgo


def RF_train(targetData, features):
	"""
	Train one RF classifier for each algorithm with training data coming from the algorithm and feature files
	
	:param targetData: the instance by algorithm table containing all runtimes
	:type targetData: ndarray
	:param features: the features corresponding to each instance
	:type features: ndarray
	:return: all trained regressors
	:rtype: list
	"""
	all_regr = list()
	nr_algo = targetData.shape[1]
	for i in xrange(nr_algo):
		clf = RandomForestClassifier(n_estimators=10)
		#clf.fit(features, np.log(targetData[:,i]))
		clf.fit(features, targetData[:,i])
		all_regr.append(clf)
	return all_regr, nr_algo

def RF_pred(testData, all_regr, nr_regr):
	"""
	Predict the best algorithm for a instance based on its features. 
	
	:param testData: the features of the instance whose best algorithm is being predicted
	:type testData: ndarray
	:param all_regr: all trained regressors, one for each algorithm
	:type all_regr: list
	:param nr_regr: number of regressors
	:type nr_regr: int
	:return: the best algorithm for the given instance
	"""
	if len(testData.shape)==1:
		predictions = np.zeros(nr_regr)
	else:
		predictions = np.zeros((nr_regr, testData.shape[0]))
	for i in xrange(len(all_regr)):
		predictions[i] = all_regr[i].predict(testData)
		#print 'predictions: ', predictions
	
	bestAlgo = np.argmin(predictions, axis=0) + 1
	return bestAlgo, predictions	

def RF_crossval(x, y, folds):
	"""
	Execute the cross validation based on the RF classifier. The target data is y, which corresponds to the table containing
	the runtimes for all combinations of instances and algorithms. 
	The input data is x, the features for all instances. The cross-validation is executed according the the folds extracted
	from the cv file.
	
	:param x: all features
	:type x: ndarray
	:param y: all runtime combinations of instances and algorithms
	:type y: ndarray
	:param folds: the folds for the cross_validation
	:type folds: ndarray
	:return: the best algorithms for each instance and the mean accuracy 
	:rtype: ndarray
	"""
	scores = np.zeros(folds.shape[0])
	all_perf = np.zeros((folds.shape[0], y.shape[1]))
	for i in xrange(folds.shape[0]):
		id_test = folds[i].astype(int)
		x_test = x[id_test]
		y_test = y[id_test]
		id_train = np.ones(x.shape[0], dtype=bool)
		id_train[id_test] = False
		x_train = x[id_train]
		y_train = y[id_train]
		all_regr, nr_algo = RF_train(y, x)
		if i == folds.shape[0] - 1:
			predss, perfs = RF_pred(x, all_regr, nr_algo)
		preds, perf = RF_pred(x_test, all_regr, nr_algo)
		#print 'perf.shape: ', perf.shape
		#print 'all_perf[i, :].shape: ', all_perf[i, :].shape
		all_perf[i, :] = np.mean(perf, axis=1)
		truth = (np.argmin(y_test, axis=1) + 1) 
		score = accuracy_score(truth, preds)
		scores[i] = score
	
	return np.mean(score), predss, np.mean(all_perf, axis=0)
	#if bestAlgo==truth:
		#correct+=1

def KN_crossval(x, y, folds):
	"""
	Execute the cross validation based on the RF classifier. The target data is y, which corresponds to the table containing
	the runtimes for all combinations of instances and algorithms. 
	The input data is x, the features for all instances. The cross-validation is executed according the the folds extracted
	from the cv file.
	
	:param x: all features
	:type x: ndarray
	:param y: all runtime combinations of instances and algorithms
	:type y: ndarray
	:param folds: the folds for the cross_validation
	:type folds: ndarray
	:return: the best algorithms for each instance and the mean accuracy 
	:rtype: ndarray
	"""
	scores = np.zeros(folds.shape[0])
	all_perf = np.zeros((folds.shape[0], y.shape[1]))
	for i in xrange(folds.shape[0]):
		id_test = folds[i].astype(int)
		x_test = x[id_test]
		y_test = y[id_test]
		id_train = np.ones(x.shape[0], dtype=bool)
		id_train[id_test] = False
		x_train = x[id_train]
		y_train = y[id_train]
		all_regr, nr_algo = KN_train(y, x)
		if i == folds.shape[0] - 1:
			predss, perfs = KN_pred(x, all_regr, nr_algo)
		preds, perf = KN_pred(x_test, all_regr, nr_algo)
		#print 'perf.shape: ', perf.shape
		#print 'all_perf[i, :].shape: ', all_perf[i, :].shape
		all_perf[i, :] = np.mean(perf, axis=1)
		truth = (np.argmin(y_test, axis=1) + 1) 
		score = accuracy_score(truth, preds)
		scores[i] = score
	
	return np.mean(score), predss, np.mean(all_perf, axis=0)		
		
		
def KN_train(trainData, features):
	"""
	Train one KNN classifier for each algorithm with training data coming from the algorithm and feature files
	
	:param targetData: the instance by algorithm table containing all runtimes
	:type targetData: ndarray
	:param features: the features corresponding to each instance
	:type features: ndarray
	:return: all trained regressors
	:rtype: list
	"""
	all_regr = list()
	nr_algo = trainData.shape[1]
	for i in xrange(nr_algo):
		clf = KNeighborsClassifier(n_neighbors=1)
		clf.fit(features, np.log(trainData[:,i]))
		#clf.fit(features, trainData[:,i].reshape(-1,1))
		all_regr.append(clf)
	return all_regr, nr_algo

def KN_pred(testData, all_regr, nr_regr):
	"""
	Predict the best algorithm for a instance based on its features. 
	
	:param testData: the features of the instance whose best algorithm is being predicted
	:type testData: ndarray
	:param all_regr: all trained regressors, one for each algorithm
	:type all_regr: list
	:param nr_regr: number of regressors
	:type nr_regr: int
	:return: the best algorithm for the given instance
	"""
	if len(testData.shape)==1:
		predictions = np.zeros(nr_regr)
	else:
		predictions = np.zeros((nr_regr, testData.shape[0]))
	for i in xrange(len(all_regr)):
		predictions[i] = all_regr[i].predict(testData)
		#print 'predictions: ', predictions
	
	bestAlgo = np.argmin(predictions, axis=0) + 1
	return bestAlgo, predictions

def getFeatures(data):
	"""
	Get the features data and transforms it accordingly, so that missing values are substituted by the most 
	frequent values in the second axis

	:param data: list of the features file corresponding to the features data
	:type data: list
	:return: an array with the transformed data
	:rtype: ndarray
	"""
	features_list = data['data']
	np_feat = np.zeros((len(features_list), len(features_list[0])-1))
	for i in xrange(len(features_list)):
		toAdd = features_list[i]
		del toAdd[0]
		toAdd = [x if x!=None else np.nan for x in toAdd]
		np_feat[i, :] = np.asarray(toAdd)

	imp = Imputer(missing_values='NaN', strategy='most_frequent', axis=1, copy=False)
	np_feat = imp.fit_transform(np_feat)
	#min_max_scaler = MinMaxScaler(copy=False)
	#np_feat = min_max_scaler.fit_transform(np_feat)
	#return np_feat, min_max_scaler
	return np_feat
	

def getCV(data):
	"""
	Transforms the cv file in a dictionary of the form dict['instance_name'] = fold
	
	:param data: list of the civ file corresponding to the cv data
	:type data: list
	:return: dictionary with corresponding fold for every instance name
	:rtype: dictionary
	"""
	cv_dict = dict()
	for i in xrange(len(data)):
		cv_dict[data[i][0]] = data[i][2]
	return cv_dict
		
				

def getDict1(data):
	"""
	It transforms the arff data in a dictionary with two keys: [instance][algorithm], which stores the corresponding runtime
	
	:param data: the loaded arff data
	:type data: dict of lists
	:return setIns: a list with all instances
	:rtype setIns: list
	:return setAlgos: a list with all algorithms
	:rtype setAlgos: list
	:return dicInsAlgo: a dictionary with two entries, one for instance, the other for algorithms, the value is a list with time and statues
	:rtype dicInsAlgo: dict of dict of list
	"""
	setIns = set()
	setAlgos = set()
	dicInsAlgo = dict()
	
	for i in xrange(len(data['data'])):
		ins = data['data'][i][0]
		setIns.add(ins)
		alg = data['data'][i][2]
		setAlgos.add(alg)
		dicAlgo = [float(data['data'][i][3]), data['data'][i][4]]
		if ins in dicInsAlgo.keys():
			dicInsAlgo[ins][alg] = dicAlgo
		else:
			dicInsAlgo[ins] = dict()
			dicInsAlgo[ins][alg] = dicAlgo
			
	
	setIns = list(setIns)
	setAlgos = list(setAlgos)
	
	return setIns, len(setIns), setAlgos, len(setAlgos), dicInsAlgo





def getNpDict(infoDict, ins_list, algo_list):
	"""
	It transform a dictionary with entries [instance][algorithm] = [runtime, status]
	into a ndarray of two dimensions, the first dimension correspondinf to the instances, 
	the second to the algorithms. The runtime is punished with 10*k, being k=5000
	
	:param infoDict: a dictionary with entries [instance][algorithm] = [runtime, status]
	:type infoDict: dict
	:param ins_list: a list of all instances
	:type ins_list: list
	:param algo_list: a list of all algorithms
	:type algo_list: list
	:return: a ndarray of two dimensions with the value equal to the punished runtime
	:rtype: ndarray
	"""
	k = 5000.
	np_dic = np.zeros((len(ins_list), len(algo_list)))
	for i in xrange(len(ins_list)):
		#print 'ins_list[i]: ', ins_list[i]
		for j in xrange(len(algo_list)):
			#print 'algo_list[j]: ', algo_list[j]
			val = infoDict[ins_list[i]][algo_list[j]][0]
			#print 'val: ', val
			if val >=k:
				np_dic[i][j] = 10*k
				#np_dic[i][j] = k + 1
			else:
				np_dic[i][j] = val
	return np_dic

def getNpDict2(infoDict, ins_list, algo_list, cv_dic):
	"""
	It transform a dictionary with entries [instance][algorithm] = [runtime, status]
	into a ndarray of two dimensions, the first dimension correspondinf to the instances, 
	the second to the algorithms. The runtime is punished with 10*k, being k=5000
	
	:param infoDict: a dictionary with entries [instance][algorithm] = [runtime, status]
	:type infoDict: dict
	:param ins_list: a list of all instances
	:type ins_list: list
	:param algo_list: a list of all algorithms
	:type algo_list: list
	:return: a ndarray of two dimensions with the value equal to the punished runtime
	:rtype: ndarray
	"""
	k = 5000.
	np_dic = np.zeros((len(ins_list), len(algo_list)))
	fold_of_instances = np.zeros(len(ins_list))
	for i in xrange(len(ins_list)):
		#print 'ins_list[i]: ', ins_list[i]
		foldHere = cv_dic[ins_list[i]]
		foldHere = int(foldHere/1)
		fold_of_instances[i] = int(foldHere)
		for j in xrange(len(algo_list)):
			#print 'algo_list[j]: ', algo_list[j]
			val = infoDict[ins_list[i]][algo_list[j]][0]
			#print 'val: ', val
			if val >=k:
				np_dic[i][j] = 10*k
				#np_dic[i][j] = k + 1
			else:
				np_dic[i][j] = val
	
	fold_list = np.zeros((10, len(ins_list)/10))
	for j in xrange(1, 11):
		foldNow = np.where(fold_of_instances==j)[0]
		#print 'foldNow: ', foldNow
		#print 'fold_list[j-1, :]: ', fold_list[j-1, :].shape
		#print 'foldNow: ', foldNow.shape
		fold_list[j-1, :] = foldNow
	return np_dic, fold_of_instances, fold_list



def run(algoruns, feat, cv):
	"""
	Predict the best algorithm for each instance based on the features
	
	:param algoruns: name of the algoruns file of type arff
	:type algoruns: string
	:param feat: name of the features file
	:type algoruns: string
	:param algoruns: name of the cv file of type arff
	:type algoruns: string 
	"""
	with open(algoruns, 'r') as f:
		data = arff.load(f)
	
	inst, inst_nr, algo, algo_nr, infoDict  = getDict1(data)
	

	with open(feat, 'r') as f:
		dataF = arff.load(f)
	with open(cv, 'r') as f:
		dataC = arff.load(f)
	
	cv_dic = getCV(dataC['data'])
	features = getFeatures(dataF)
	np_dict, fold_of_instances, fold_list = getNpDict2(infoDict, inst, algo, cv_dic)
	
	a, preds, all_perf = RF_crossval(features, np_dict, fold_list)
	#a, preds, all_perf = KN_crossval(features, np_dict, fold_list)
	print 'PAR10 performance: ', np.mean(all_perf)
	print 'Selection per instance: '
	for i in xrange(preds.shape[0]):
		#toShow = "".join["instance", str(i+1), ".cnf, algo", str(preds[i])] 
		toShow = "instance" + str(i+1) + ".cnf, algo" + str(preds[i])
		print toShow
	#print 'all_perf: '
	#print all_perf
		
	
	

if __name__== "__main__":
	parser = argparse.ArgumentParser(description='Exercise Mload 6-3')
	parser.add_argument('--algoruns', type=str, default='algorithm_runs1.arff',  help='Name of the arff file')
	parser.add_argument('--features', type=str, default='feature_values1.arff',  help='Name of the features file')
	parser.add_argument('--cv', type=str, default='cv1.arff',  help='Name of the cv file')
	arg = parser.parse_args()
	run(arg.algoruns, arg.features, arg.cv)
