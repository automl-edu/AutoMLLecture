import arff
import json
import os
import numpy as np
import sys
import time
import argparse
from random import randint
from copy import deepcopy


def getDict1(data):
	"""
	It transforms the arff data in a dictionary with two keys: [instance][algorithm], which stores the corresponding runtime
	
	:param data: the loaded arff data
	:type data: dict of lists
	:return setIns: a list with all instances
	:rtype setIns: list
	:return setAlgos: a list with all algorithms
	:rtype setAlgos: list
	:return dicInsAlgo: a dictionary with two entries, one for instance, the other for algorithms, the value is a list with time and statues
	:rtype dicInsAlgo: dict of dict of list
	"""
	setIns = set()
	setAlgos = set()
	dicInsAlgo = dict()
	
	for i in xrange(len(data['data'])):
		ins = data['data'][i][0]
		setIns.add(ins)
		alg = data['data'][i][2]
		setAlgos.add(alg)
		dicAlgo = [float(data['data'][i][3]), data['data'][i][4]]
		if ins in dicInsAlgo.keys():
			dicInsAlgo[ins][alg] = dicAlgo
		else:
			dicInsAlgo[ins] = dict()
			dicInsAlgo[ins][alg] = dicAlgo
			
	
	setIns = list(setIns)
	setAlgos = list(setAlgos)
	
	return setIns, len(setIns), setAlgos, len(setAlgos), dicInsAlgo




def getOracle(np_dict):
	"""
	Calculate the oracle value
	
	:param np_dict: a two dimensional ndarray with the corresponding runtime values
	:type np_dict: ndarray
	:return: the mean value of the minima corresponding to each instance
	:rtype: float 
	"""
	mins = np.min(np_dict, axis=1)
	#if np_dict.shape[0] == mins.shape[0]:
	return np.mean(mins, axis=0)	


def getSB(np_dict):
	"""
	Calculate the Single Best value
	
	:param np_dict: a two dimensional ndarray with the corresponding runtime values
	:type np_dict: ndarray
	:return: the minimum value of the meanas corresponding to each algorithm
	:rtype: float 
	"""
	return np.min(np.mean(np_dict, axis=0))

def getNpDict(infoDict, ins_list, algo_list):
	"""
	It transform a dictionary with entries [instance][algorithm] = [runtime, status]
	into a ndarray of two dimensions, the first dimension correspondinf to the instances, 
	the second to the algorithms. The runtime is punished with 10*k, being k=5000
	
	:param infoDict: a dictionary with entries [instance][algorithm] = [runtime, status]
	:type infoDict: dict
	:param ins_list: a list of all instances
	:type ins_list: list
	:param algo_list: a list of all algorithms
	:type algo_list: list
	:return: a ndarray of two dimensions with the value equal to the punished runtime
	:rtype: ndarray
	"""
	k = 5000.
	np_dic = np.zeros((len(ins_list), len(algo_list)))
	for i in xrange(len(ins_list)):
	
		for j in xrange(len(algo_list)):
			#print 'algo_list[j]: ', algo_list[j]
			val = infoDict[ins_list[i]][algo_list[j]][0]
			#print 'val: ', val
			if val >=k:
				np_dic[i][j] = k+0.1
			else:
				np_dic[i][j] = val
	return np_dic

def getNpDict2(infoDict, ins_list, algo_list):
	"""
	It transform a dictionary with entries [instance][algorithm] = [runtime, status]
	into a ndarray of two dimensions, the first dimension correspondinf to the instances, 
	the second to the algorithms. The runtime is punished with 10*k, being k=5000
	
	:param infoDict: a dictionary with entries [instance][algorithm] = [runtime, status]
	:type infoDict: dict
	:param ins_list: a list of all instances
	:type ins_list: list
	:param algo_list: a list of all algorithms
	:type algo_list: list
	:return: a ndarray of two dimensions with the value equal to the punished runtime
	:rtype: ndarray
	"""
	k = 5000.
	np_dic = np.zeros((len(ins_list), len(algo_list)))
	for i in xrange(len(ins_list)):
		#print 'ins_list[i]: ', ins_list[i]
		for j in xrange(len(algo_list)):
			#print 'algo_list[j]: ', algo_list[j]
			val = infoDict[ins_list[i]][algo_list[j]][0]
			#print 'val: ', val
			np_dic[i][j] = val
			#if val >=k:
				#np_dic[i][j] = 10*k
			#else:
				#np_dic[i][j] = val
	return np_dic

def show_result(assig, permut):
	assig_show = dict()
	permut_show = list()
	for i in xrange(assig.shape[0]):
		alg_name = "algo" + str(i+1)
		assig_show[alg_name] = assig[i]
		alg_name = "algo" + str(permut[i] +1)
		permut_show.append(alg_name)
	print 'assignment: ', assig_show
	print 'permutation: ', permut_show
	
def run(algoruns):
	"""
	Calculate the oracle and the single best value for a given algoruns file of type arff
	
	:param algoruns: name of the algoruns file of type arff
	:type algoruns: string
	"""
	with open(algoruns, 'r') as f:
		data = arff.load(f)
	
	inst, inst_nr, algo, algo_nr, infoDict  = getDict1(data)
	np_dict = getNpDict(infoDict, inst, algo)
	best_assig = ils_timeout(np_dict)
	best_permute = ils_permute(np_dict, best_assig)
	show_result(best_assig, best_permute)
	#print 'assignment: ', best_assig
	#print 'permutation: ', best_permute
    
	


def pertubation(nrAlgo, k=5000):
	"""
	Creates a new time slices assignment. The values are randomly calculated in such a way,
	that they sum up to the cutoff value
	
	:param nrAlgo: number of algorithms
	:type nrAlgo: integer
	:param k: cutoff value
	:type k: integer
	:return: time slice assignments for every algorithm
	:rtype: ndarray
	"""
	percents = np.random.rand(nrAlgo)
	percents = percents/np.sum(percents)
	assign = np.zeros(nrAlgo)
	
	for i in xrange(nrAlgo):
		assign[i] = int(k*percents[i])
	
	
	
	return assign


def local_search(assign, timeout, np_dict, k=5000, p=0.2, trials=10):
	"""
	Performs a local search for the timeout minimization ILS. It randomly chooses a value that represent from 5% to 20%
	of the allowed interval for each algorithm, taking in consideration the actual best assignment. It's under the constraint
	of keeping all values summing up to the cutoff value
	
	:param assign: the current time slices assignment
	:type assign: ndarray
	:param timeout: the current best timeout
	:type timeout: integer
	:param np_dict: the table containing the relation of all instances(rows) and algorithms(columns)
	:type np_dict: ndarray
	:param k: cutoff value
	:type k: integer
	:param trials: how many times the local search is to be executed
	:type trial: integer
	:return: a new assigment in case the local search finds a better value than the value delivered by the global search
	:rtype: ndarray
	"""
	localBest = deepcopy(assign)
	#index = randint(0, assign.shape[0] -1)
	#oldVal = localBest[index]
	#intLow = int(-oldVal*p)
	#intUpper =  int((k - oldVal)*p)
	outBest = timeout
	
	
	#for n trials
	for i in xrange(trials):
		var_percents = np.random.choice([0.05, 0.06, 0.07,0.08,0.09, 0.1, 0.11, 0.12, 0.13, 0.14, 0.15, 0.16, 0.17, 0.18, 0.19, 0.20], assign.shape[0])
		assignHere = local_search_step(assign, np_dict, var_percents, k)
		timeoutNow = timeoutCount(assignHere, np_dict)
		if timeoutNow <= outBest:
			outBest = timeoutNow
			localBest = assignHere
	
	return localBest, outBest

def local_search_step(assign, np_dict, var_percents, k):
	"""
	Executes a smaller step of the function local_search(). It creates a hypothetical new assignment in the local region
	of the search space.
	
	:param assign: the current time slices assignment
	:type assign: ndarray
	:param np_dict: the table containing the relation of all instances(rows) and algorithms(columns)
	:type np_dict: ndarray
	:param var_percents: an array with the percentages of the interval (5% to 20%) for each algorithm
	:type var_percents: ndarray	
	:param k: cutoff value
	:type k: integer
	:return: the possible new assignment
	:rtype: ndarray
	"""
	new_assign = np.zeros(assign.shape[0])
	for i in xrange(len(assign)):
		oldVal = assign[i]
		intLow = int(-oldVal*var_percents[i])
		#print 'intLow: ', intLow
		intUpper = int((k - oldVal)*var_percents[i])
		#print 'intUpper: ', intUpper
		newVal = oldVal + np.random.choice([intLow, intUpper], 1)
		new_assign[i] = newVal
	return new_assign

def local_search_perm(permute, exc_time, assign, np_dict, k=5000, p=0.2, trials=10):
	"""
	Performs a local search for the permutation minimization ILS. It changes randomly two values of the assignment.
	It tries 'trials' number of change. The change happens always on the parameter 'permute'.
	
	:param permute: the current best permutation
	:tyoe permute: ndarray
	:param assign: the current time slices assignment
	:type assign: ndarray
	:param exc_time: the current best time of the best permutation
	:type exc_time: integer
	:param np_dict: the table containing the relation of all instances(rows) and algorithms(columns)
	:type np_dict: ndarray
	:param k: cutoff value
	:type k: integer
	:param trials: how many times the local search is to be executed
	:type trials: integer
	:return: a new assigment in case the local search finds a better value than the value delivered by the global search
	:rtype: ndarray
	"""
	localBest = deepcopy(permute)
	timeBest = exc_time
	
	for i in xrange(trials):
		change_pos = np.random.choice(np.arange(permute.shape[0]), 2)
		permuteHere = deepcopy(permute) 
		permuteHere[change_pos[0]] = permute[change_pos[1]]
		permuteHere[change_pos[1]] = permute[change_pos[0]]
		extime_Now = calc_time(assign, permuteHere, np_dict)
		if extime_Now <= timeBest:
			timeBest = extime_Now
			localBest = permuteHere
	
	return localBest, timeBest
		



def timeoutCount(assign, np_dict):
	'''
	Count the number of timeouts for a given assignment
	
	:param assign: runtime assignment for each algorithm. 
	:type assign: ndarray
	:param np_dict: the table containing the relation of all instances(rows) and algorithms(columns)
	:type np_dict: ndarray
	:return: the number of timeouts for the given assignment
	:rtype: integer
	'''
	timeout_nr = 0
	
	for i in xrange(np_dict.shape[0]):
		
		#timeout = satisfy(np_dict[i, :], assign)
		timeout = countInstace(np_dict[i, :], assign)
		timeout_nr += timeout
	
	return timeout_nr
	
def countInstace(instance, assign):
	'''
	Count the timeout for a given problem instance and an assignment
	
	:param instance: a problem instance with the runtimes for each algorithm
	:type instance: ndarray
	:param assign: a time slice assigment for the algorithms
	:type assign: ndarray
	:return: timeout for a given problem instance
	:rtype: integer
	'''
	timeout = 0
	for i in xrange(assign.shape[0]):
		if not assign[i] >= instance[i]:
		#if assign[i] >= instance[i]:
			timeout+=1
	return timeout


def ils_timeout(np_dict):
	"""
	Iterated Local Search for the minimal timeout
	
	:param np_dict: a two dimensional ndarray with the corresponding runtime values
	:type np_dict: ndarray
	:return: the minimal timeout slice assignment
	:rtype: ndarray
	"""
	nrVar = np_dict.shape[1]
	best_assig = pertubation(nrVar)
	best_timeout = timeoutCount(best_assig, np_dict)
	start = time.time()
	budget = 200
	
	while time.time() - start < budget:
		#print 'Im here'
		temp_assig = pertubation(nrVar)
		
		temp_timeout = timeoutCount(temp_assig, np_dict)
		
		if temp_timeout <= best_timeout:
			best_timeout = temp_timeout
			best_assig = temp_assig
			#print 'best_timeout: ', best_timeout
			#print 'best_assign: ', best_assig
			#best_assig, best_timeout = local_search(best_assig, best_timeout, np_dict, k=5000, p=0.2, trials=3)
			#print 'new best_timeout: ', best_timeout
			#print 'new best_assign: ', best_assig
			#print
	return best_assig

def ils_permute(np_dict, assig):
	"""
	Iterated Local Search for the permutation minimal time
	
	:param np_dict: a two dimensional ndarray with the corresponding runtime values
	:type np_dict: ndarray
	:return: the time-optimal permutation
	:rtype: ndarray
	"""
	nrVar = np_dict.shape[1]
	best_permute = permute(nrVar)
	best_time = calc_time(assig, best_permute, np_dict)
	start = time.time()
	budget = 100
	
	while time.time() - start < budget:
		temp_permute = permute(nrVar)
		
		temp_time = calc_time(assig, temp_permute, np_dict)
		
		if temp_time <= best_time:
			best_time = temp_time
			best_permute = temp_permute
			#print 'best_time: ', best_time
			#print 'best_permute: ', best_permute
									 #local_search_perm(permute, exc_time, assign, np_dict, k=5000, p=0.2, trials=10)
			best_permute, best_time = local_search_perm(best_permute, best_time, assig, np_dict, k=5000, p=0.2, trials=3)
			#print 'new best_time: ', best_time
			#print 'new best_permute: ', best_permute
			#print
	return best_permute
		
def calc_time(assig, permut, np_dict):
	"""
	Calculate the average time of a whole table with instances and algorithms 
	for a given assignment and a given permutation
	:param assig: the assignment of time slices
	:type assig: ndarray
	:param permut: the permutation of the algorithms
	:type permut: ndarray
	:param np_dict: table with the runtime for all combinations of instances and algorithms
	:type np_dict: ndarray
	:return: the mean time of the achieved times for each instance
	:rtype: float
	"""
	exc_times = np.zeros(np_dict.shape[0])
	
	for j in xrange(len(exc_times)):
		exc_times[j] = calc_time_step(assig, permut, np_dict[j,:])
	
	return np.mean(exc_times)

def calc_time_step(assig, permut, instance):
	"""
	Calculate the time for given instance, assignment and permutation
	:param assig: assignment of time slices
	:type assig: ndarray
	:param permut: the permutation of the algorithms
	:type permut: ndarray
	:param instance: a problem instance from the runsolver table
	:type instance: ndarray
	:return: the necessary time for solving the instance
	:rtype: integer
	"""
	t = 0
	achieved = False
	index = 0
	
	while not achieved and index < assig.shape[0]:
		#if assig[permut[index]] <= instance[permut[index]]:
		if assig[permut[index]] >= instance[permut[index]]:
			#t+=	assig[permut[index]]
			t+=	instance[permut[index]]
			achieved = True
		else:
			#t+=	instance[permut[index]]
			t+=	assig[permut[index]]
			index+=1
	
	if t>=5000 or t==0 or achieved == False:
		return 50000
	else:
		return t

def permute(nr_algos):
	"""
	Generate a random permutation for the time slices of the corresponding algorithms
	
	:param nr_algos: number of algorithms in the portfolio
	:type nr_algos: integer
	:return: an array with the permutations
	:rtype: ndarray
	"""
	a= np.arange(nr_algos)
	np.random.shuffle(a)
	return a
	


if __name__== "__main__":
	parser = argparse.ArgumentParser(description='Exercise Mload 6-2')
	parser.add_argument('--algoruns', type=str, default='algorithm_runs1.arff',  help='Name of the arff file')
	arg = parser.parse_args()
	run(arg.algoruns)
