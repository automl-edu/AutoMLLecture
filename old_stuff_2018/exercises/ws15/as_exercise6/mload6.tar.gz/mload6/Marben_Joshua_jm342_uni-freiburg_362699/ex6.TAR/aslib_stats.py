import arff
import sys

def singleBest(path):    
    """Determine the single best algorithm performance
    in the given scenario

    Keyword arguments:
    path -- String with the relative path to the scenario
    """
    data = arff.load(open(path))
    dictPerformance = {}
    for a in data["data"]:
        performance = a[3]
        if a[4] != 'ok':
            performance = performance * 10
        if a[2] not in dictPerformance:
            dictPerformance[a[2]] = performance
        else:
            dictPerformance[a[2]] += performance
    return dictPerformance[min(dictPerformance, key=dictPerformance.get)]

def oracle(path):    
    """Determine the oracle performance in the given scenario

    Keyword arguments:
    path -- String with the relative path to the scenario
    """
    data = arff.load(open(path))
    dictPerformance = {}
    for a in data["data"]:
        performance = a[3]
        if a[4] != 'ok':
            performance = performance * 10
        if a[0] not in dictPerformance:
            dictPerformance[a[0]] = performance
        elif dictPerformance[a[0]] > performance:
            dictPerformance[a[0]] = performance
    return sum(dictPerformance.values())

if "__main__" == __name__:
    path = sys.argv[2]
    print(path)
    #print("Oracle: " + str(oracle("as_exercise6/SAT11-RAND/" + path)))
    #print("Single Best: " + str(singleBest("as_exercise6/SAT11-RAND/" + path)))
    print("Oracle: " + str(oracle(path)))
    print("Single Best: " + str(singleBest(path)))
    