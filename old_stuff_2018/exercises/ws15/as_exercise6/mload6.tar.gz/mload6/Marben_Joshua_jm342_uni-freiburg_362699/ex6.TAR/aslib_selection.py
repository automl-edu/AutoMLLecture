import arff
import sys
import numpy as np
from sklearn.preprocessing import Imputer
from sklearn.neighbors import KNeighborsClassifier

def readX(path):
    data = arff.load(open(path))
    array = np.array(data["data"])
    array = np.hsplit(array, [1])
    imp = Imputer()
    for x in np.nditer(array, op_flags=['readwrite']):
        if array[0] == '?':
            array[0] = 'NaN'
    print(array[1])
    array = np.hstack((array[0],imp.fit_transform(array[1])))
    return array

def readY(path):
    """
    Returns dictionary!
    """
    data = arff.load(open(path))
    dictAlgoInstPerf = {}  # {Algo: {Inst: Perf}}
    for a in data["data"]:
        performance = a[3]
        if a[4] != 'ok':
            performance = performance * 10
        if a[2] not in dictAlgoInstPerf:
            dictAlgoInstPerf[a[2]] = {}
        if a[0] not in dictAlgoInstPerf[a[2]]:
            dictAlgoInstPerf[a[2]][a[0]] = performance
        else:
            print("Repition!")
    return dictAlgoInstPerf

    
def kNN(path):
    Xpre = readX("as_exercise6/SAT11-INDU/feature_values.arff")
    ypre = readY("as_exercise6/SAT11-INDU/algorithm_runs.arff")
    algoKNNdict = {}
    for algo in ypre:
        algoKNNdict[algo] = KNeighborsClassifier()
    for algo in ypre:
        newList = [[],[]]
        for inst in Xpre:
            if inst[0] in ypre[algo]:
                newList[0].append(inst[1:])
                newList[1].append(ypre[algo][inst[0]])
        X = np.array(newList[0])
        y = np.array([newList[1]])
        algoKNNdict[algo].fit(X,y)
    


if "__main__" == __name__:
    #path = sys.argv[2]
    data = kNN("as_exercise6/SAT11-INDU/feature_values.arff")
    #for a in data:
    #    print str(a)