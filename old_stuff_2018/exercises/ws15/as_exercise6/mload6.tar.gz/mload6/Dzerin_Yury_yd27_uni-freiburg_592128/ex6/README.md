Required Packages
=================

This code needs Cython to run together with the `pyximport` package.
It also uses the `optparse` package.