# -*- coding: utf-8 -*-

import sklearn
import sklearn.preprocessing
import sklearn.linear_model
import numpy as np
import arff
import sys
from optparse import OptionParser
from aslib_stats import AlgPerfomanceData
from sklearn.ensemble import RandomForestClassifier

class RandomForestClassifierWrapper:
    def __init__(self, alg_performances, instantce_feature_matrix, instance_name_to_feature_matrix_row_map):
        self.alg_performances = alg_performances
        self.instantce_feature_matrix = instantce_feature_matrix
        self.instance_name_to_feature_matrix_row_map = instance_name_to_feature_matrix_row_map

        self.clf = RandomForestClassifier(n_estimators=21,
                                          criterion="gini",
                                          max_features="sqrt",
                                          min_samples_split=3,
                                          min_samples_leaf=10)
    def fit(self, instance_names):
        training_feature_matrix = np.ndarray((len(instance_names), self.instantce_feature_matrix.shape[1]))
        training_best_algorithms = [self.alg_performances.get_best_alg(inst_name) for inst_name in instance_names]

        for inst_id, inst_name in enumerate(instance_names):
            training_feature_matrix[inst_id, :] = self.instantce_feature_matrix[self.instance_name_to_feature_matrix_row_map[inst_name], :]

        self.clf.fit(training_feature_matrix, training_best_algorithms)

    def predictBestAlgorithm(self, instance_features):
        return self.clf.predict(instance_features)[0]

    def computePAR10Performance(self, instance_feature_list, instance_key_list):
        par10 = 0
        for instance_features, instance in zip(instance_feature_list, instance_key_list):
            par10 = par10 + self.alg_performances.m(instance, self.predictBestAlgorithm(instance_features))
        return par10/len(instance_key_list)


class PairwiseDifferenceRidgeRegression:
    '''
    A class to do ridge regression on pairwise differences of algorithm
    performances. It can be used to predict which algorithm should perform
    best on an instance, given some instance features.
    Its interface is similar to that of sklearn.
    '''

    def __init__(self, alg_performances, instantce_feature_matrix, instance_name_to_feature_matrix_row_map):
        '''
        Creates a new instance of a pairwise difference ridge regression thingy

        @param alg_performances An instance of AlgPerfomanceData that provides
               access to the algorithm performance data.
        @param instance_feature_matrix a numpy array containging one set of
               instance features per row
        @param instance_name_to_feature_matrix_row_map A map, that maps
               instanc names to row indices in the above feature matrix.
        '''
        self.alg_performances = alg_performances
        self.instantce_feature_matrix = instantce_feature_matrix
        self.instance_name_to_feature_matrix_row_map = instance_name_to_feature_matrix_row_map
        self.runtime_delta_classifiers = dict()

    def fit(self, instance_names):
        '''
        Fits the model to the instances specified in instance_names.
        The actual data to train on (e.g. algorithm performance data) and
        features is taken from the alg_performances object that was provided to
        the constructor.
        '''
        # Remove any old classifiers
        self.runtime_delta_classifiers = dict()

        # Crate a feature matrix for the given instance names
        training_feature_matrix = np.ndarray((len(instance_names), self.instantce_feature_matrix.shape[1]))
        for inst_id, inst_name in enumerate(instance_names):
            training_feature_matrix[inst_id, :] = self.instantce_feature_matrix[self.instance_name_to_feature_matrix_row_map[inst_name], :]

        # Train a ridge regression for each touple of algorithms
        algorithms = self.alg_performances.algorithms
        for a_id in range(len(algorithms)):
            for a_prime_id in range(a_id+1, len(algorithms)):
                # Get the algorithm names
                a = algorithms[a_id]
                a_prime = algorithms[a_prime_id]

                # Generate the differences
                target_classifications = np.array([self.alg_performances.m(inst, a) - self.alg_performances.m(inst, a_prime) for inst in instance_names])

                # Create the ridge model an train it
                model = sklearn.linear_model.Ridge(solver='sparse_cg', alpha=0, normalize=True)
                model.fit(training_feature_matrix, target_classifications)
                self.runtime_delta_classifiers[(a, a_prime)] = model

    def predictRuntimeDelta(self, a, a_prime, instance_features):
        '''
        Predicts the runtime difference of the two algorithms a and a_prime
        on an instnace with the given instance features. If no classifier has
        been trained on that pair of algorithms, a value error is thrown.

        @param a The name of the first algorithm to comapre
        @param a_prime The name of the second algorithm to compare
        @param instance_features The instance features to base the
               classification on
        '''
        if a == a_prime:
            return 0
        if (a, a_prime) in self.runtime_delta_classifiers:
            return self.runtime_delta_classifiers[(a, a_prime)].predict(instance_features)
        elif (a_prime, a) in self.runtime_delta_classifiers:
            return -self.runtime_delta_classifiers[(a_prime, a)].predict(instance_features)
        else:
            raise ValueError("We can't find a predictor for {} and {}".format(a, a_prime))

    def score(self, a, instance_features):
        '''
        Computes a score on how well an algorithm should perform on an instance
        with the given features. It is just the sum over all its predicted run-
        time deltas to other algorithms.

        @param a The name (string) of the algorithm
        @param instance_features A numpy array with the features of the instance
        '''
        return sum([self.predictRuntimeDelta(a, a_prime, instance_features) for a_prime in self.alg_performances.algorithms])

    def predictBestAlgorithm(self, instance_features):
        '''
        Predicts the best algorithm for a given set of instance features.
        It just returns the algorithm with the maximal score on that instance.
        '''
        return min(self.alg_performances.algorithms, key=lambda a: self.score(a, instance_features))

    def computePAR10Performance(self, instance_feature_list, instance_key_list):
        '''
        Computes the PAR10 performance on a list of feature sets.
        First the best algorithm is predicted for each instance, then the overal
        runtime ot those best predicted algorithms is summed up.

        @param instance_feature_list A list with instance feature sets
        @param instance_key_list A list holding the instance key/name for each
               of the feature sets.
        '''
        par10 = 0
        for instance_features, instance in zip(instance_feature_list, instance_key_list):
            par10 = par10 + self.alg_performances.m(instance, self.predictBestAlgorithm(instance_features))
        return par10/len(instance_key_list)


def main(argv):
    parser = OptionParser()
    parser.add_option("-a", "--algoruns", type="string", dest="algorithm_runs",
                  help="Read algorithms runs from file", metavar="FILE")

    parser.add_option("-f", "--features", type="string", dest="feature_values",
                  help="Read instance features of each instance from file", metavar="FILE")

    parser.add_option("-c", "--cv", type="string", dest="cv",
                  help="Read cross-validation splits from file", metavar="FILE")

    parser.add_option("-m", "--method", type="choice", dest="method",
                  help="Make a choice between Pairwise Difference Ridge Regression (PDRR) or Random Forest Classifier (RFC)", choices=["PDRR", "RFC"], default="PDRR")

    (options, args) = parser.parse_args()
    if options.algorithm_runs is None:
        parser.error('Algorithms runs file is not specified')
    if options.feature_values is None:
        parser.error('Features values file is not specified')
    if options.cv is None:
        parser.error('Cross-validation splits file is not specified')

    # Load the arff files
    fv = arff.load(open(options.feature_values))
    cv = arff.load(open(options.cv))

    # Extract the feature matrix and impute missing values
    instance_name_to_feature_matrix_row_map = dict()
    feature_matrix = np.empty((len(fv['data']), len(fv['attributes'])-1))
    for id, instance in enumerate(fv['data']):
        feature_matrix[id, :] = instance[1:] # we skip the firs elementin in the instnace row because that is its name
        instance_name_to_feature_matrix_row_map[instance[0]] = id
    feature_matrix = sklearn.preprocessing.Imputer().fit_transform(feature_matrix)

    # Extract runtimes
    alg_performances = AlgPerfomanceData(options.algorithm_runs)

    perf_predictor = 0
    # Construct a pairwise difference ridge regression
    if options.method == "PDRR":
        perf_predictor = PairwiseDifferenceRidgeRegression(alg_performances, feature_matrix, instance_name_to_feature_matrix_row_map)
    else:
        perf_predictor = RandomForestClassifierWrapper(alg_performances, feature_matrix, instance_name_to_feature_matrix_row_map)

    # Compute crossvalidation
    folds = set([dataitem[2] for dataitem in cv['data']])
    par10s = []
    for fold in folds:
        # Split up the data into training and test set
        train_instances = [dataitem[0] for dataitem in cv['data'] if dataitem[2] != fold]
        test_instances = [dataitem[0] for dataitem in cv['data'] if dataitem[2] == fold]
        test_features = [feature_matrix[instance_name_to_feature_matrix_row_map[instance]] for instance in test_instances]

        # Train on the training set
        perf_predictor.fit(train_instances)

        # Compute PAR10
        par10s.append(perf_predictor.computePAR10Performance(test_features, test_instances))

    cross_validated_par10 = sum(par10s)/float(len(par10s))
    print "PAR10 performance:", cross_validated_par10



    # Train the ridge regression on all instances
    perf_predictor.fit(alg_performances.instances)

    print "Selection per instance:"
    # Print out the predicted selection per instance
    for instance in instance_name_to_feature_matrix_row_map.keys():
        inst_id = instance_name_to_feature_matrix_row_map[instance]
        best_pred_alg = perf_predictor.predictBestAlgorithm(feature_matrix[inst_id])
        print "{}, {}".format(instance, best_pred_alg)

if __name__ == "__main__":
    main(sys.argv[1:])
