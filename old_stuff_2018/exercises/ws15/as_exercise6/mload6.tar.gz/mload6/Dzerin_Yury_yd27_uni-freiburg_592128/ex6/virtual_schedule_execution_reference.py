# -*- coding: utf-8 -*-
from aslib_stats import AlgPerfomanceData
import pyximport
pyximport.install()
import numpy as np

from virtual_schedule_execution import execute_schedule

def execute_schedule_ref(assignment, permutation, alg_performance_data):
    '''
    Computes the time it would take to execute an algorithm schedule on all
    instances proveded in alg_performance_data. This is the slow, pure python
    reference implementation.

    @param assignment A map assigning a timeout for each algorithm in the
           schedule.
    @param permutation A list of algorithm names to designate the irder in
           which the available algorithms are to be tried.
    @param alg_performance_data An instance of PairwiseDifferenceRidgeRegression
           that provides access to the runtimes of tha algorithms on the
           different instances.
    '''
    total_virtual_time = 0.
    for instance in alg_performance_data.instances:
        individual_virtual_time = 0
        instance_solved = False
        for alg in permutation:
            assigned_time = assignment[alg]
            required_time = alg_performance_data.m(instance, alg)
            individual_virtual_time = individual_virtual_time + min(assigned_time, required_time)
            if assigned_time >= required_time:
                instance_solved = True
                break
        if not instance_solved:
            individual_virtual_time = individual_virtual_time * 10
        total_virtual_time += individual_virtual_time
    return total_virtual_time/len(alg_performance_data.instances)

def execute_schedule_fast(assigment, permutation, alg_performance_data):
    '''
    This is a wrapper around a faster cython implementation of
    execute_schedule_ref so it has the same interface.
    '''
    new_assignment = np.array([assigment[alg] for alg in alg_performance_data.algorithms], dtype=float)
    new_permutation = np.array([alg_performance_data.alg_ids[alg] for alg in permutation], dtype=int)
    return execute_schedule(new_assignment, new_permutation, alg_performance_data.fast_access_array)



test_instances = [{
    "expected" : 6441809.59459,
    "assigment" : {u'EagleUP_1.565.350': 625.5555555555557,
                 u'MPhaseSAT_M_2011-02-16': 0.5555555555555429,
                 u'sparrow2011_sparrow2011_ubcsat1.2_2011-03-02': 2364.5555555555557,
                 u'sattime2011_2011-03-02': 4.555555555555543,
                 u'SAT09referencesolvermarch_hi_hi': 51.55555555555566,
                 u'SAT09referencesolvergnovelty+2_2009-03-22': 0.5555555555556566,
                 u'SAT09referencesolverTNM_2009-03-22': 0.5555555555555429,
                 u'adaptg2wsat2011_2011-03-02': 32.55555555555554,
                 u'march_rw_2011-03-02': 1919.5555555555557},
    "permutation": [u'sattime2011_2011-03-02', u'SAT09referencesolvermarch_hi_hi', u'sparrow2011_sparrow2011_ubcsat1.2_2011-03-02', u'adaptg2wsat2011_2011-03-02', u'march_rw_2011-03-02', u'EagleUP_1.565.350', u'MPhaseSAT_M_2011-02-16', u'SAT09referencesolverTNM_2009-03-22', u'SAT09referencesolvergnovelty+2_2009-03-22'],
    "alg_performance_data" : AlgPerfomanceData("as_exercise6/SAT11-RAND/algorithm_runs.arff")
    }, {
    "expected" : 5364.45430333,
    "assigment" : {'EagleUP_1': 1666.6666666666667,
                 'SAT09refe': 1666.6666666666667,
                 'sparrow20': 1666.6666666666667},
    "permutation": ['sparrow20', 'SAT09refe', 'EagleUP_1'],
    "alg_performance_data" : AlgPerfomanceData("as_exercise6/test/algorithm_runs.arff")
    }, {
    "expected" : 7844961.20978,
    "assigment" : {u'EagleUP_1.565.350': 555.5555555555555,
                 u'MPhaseSAT_M_2011-02-16': 555.5555555555555,
                 u'sparrow2011_sparrow2011_ubcsat1.2_2011-03-02': 545.5555555555555,
                 u'sattime2011_2011-03-02': 575.5555555555555,
                 u'SAT09referencesolvermarch_hi_hi': 545.5555555555555,
                 u'SAT09referencesolvergnovelty+2_2009-03-22': 565.5555555555555,
                 u'SAT09referencesolverTNM_2009-03-22': 555.5555555555555,
                 u'adaptg2wsat2011_2011-03-02': 535.5555555555555,
                 u'march_rw_2011-03-02': 565.5555555555555},
    "permutation": [u'sparrow2011_sparrow2011_ubcsat1.2_2011-03-02', u'march_rw_2011-03-02', u'EagleUP_1.565.350', u'adaptg2wsat2011_2011-03-02', u'MPhaseSAT_M_2011-02-16', u'SAT09referencesolverTNM_2009-03-22', u'sattime2011_2011-03-02', u'SAT09referencesolvergnovelty+2_2009-03-22', u'SAT09referencesolvermarch_hi_hi'],
    "alg_performance_data" : AlgPerfomanceData("as_exercise6/SAT11-RAND/algorithm_runs.arff")
    }, {
    "expected" : 2617.00248667,
    "assigment" : {u'EagleUP_1': 5.6666666666667425,
                 u'SAT09refe': 30.666666666666742,
                 u'sparrow20': 4963.666666666667},
    "permutation": [u'EagleUP_1', u'SAT09refe', u'sparrow20'],
    "alg_performance_data" : AlgPerfomanceData("as_exercise6/test/algorithm_runs.arff")
    }, {
    "expected" : 7895616.89158,
    "assigment" : {u'EagleUP_1.565.350': 555.5555555555555,
                 u'MPhaseSAT_M_2011-02-16': 555.5555555555555,
                 u'sparrow2011_sparrow2011_ubcsat1.2_2011-03-02': 555.5555555555555,
                 u'sattime2011_2011-03-02': 555.5555555555555,
                 u'SAT09referencesolvermarch_hi_hi': 555.5555555555555,
                 u'SAT09referencesolvergnovelty+2_2009-03-22': 555.5555555555555,
                 u'SAT09referencesolverTNM_2009-03-22': 555.5555555555555,
                 u'adaptg2wsat2011_2011-03-02': 555.5555555555555,
                 u'march_rw_2011-03-02': 555.5555555555555},
    "permutation": [u'EagleUP_1.565.350', u'MPhaseSAT_M_2011-02-16', u'sparrow2011_sparrow2011_ubcsat1.2_2011-03-02', u'sattime2011_2011-03-02', u'SAT09referencesolvermarch_hi_hi', u'SAT09referencesolvergnovelty+2_2009-03-22', u'SAT09referencesolverTNM_2009-03-22', u'adaptg2wsat2011_2011-03-02', u'march_rw_2011-03-02'],
    "alg_performance_data" : AlgPerfomanceData("as_exercise6/SAT11-RAND/algorithm_runs.arff")
    }, {
    "expected" : 6441809.59459,
    "assigment" : {u'EagleUP_1.565.350': 625.5555555555557,
                 u'MPhaseSAT_M_2011-02-16': 0.5555555555555429,
                 u'sparrow2011_sparrow2011_ubcsat1.2_2011-03-02': 2364.5555555555557,
                 u'sattime2011_2011-03-02': 4.555555555555543,
                 u'SAT09referencesolvermarch_hi_hi': 51.55555555555566,
                 u'SAT09referencesolvergnovelty+2_2009-03-22': 0.5555555555556566,
                 u'SAT09referencesolverTNM_2009-03-22': 0.5555555555555429,
                 u'adaptg2wsat2011_2011-03-02': 32.55555555555554,
                 u'march_rw_2011-03-02': 1919.5555555555557},
    "permutation": [u'sattime2011_2011-03-02', u'SAT09referencesolvermarch_hi_hi', u'sparrow2011_sparrow2011_ubcsat1.2_2011-03-02', u'adaptg2wsat2011_2011-03-02', u'march_rw_2011-03-02', u'EagleUP_1.565.350', u'MPhaseSAT_M_2011-02-16', u'SAT09referencesolverTNM_2009-03-22', u'SAT09referencesolvergnovelty+2_2009-03-22'],
    "alg_performance_data" : AlgPerfomanceData("as_exercise6/SAT11-RAND/algorithm_runs.arff")
    }
]

def do_test_instance_all(instance):
    assigment = instance['assigment']
    permutation = instance['permutation']
    alg_performance_data = instance['alg_performance_data']
    print "Expected:", instance['expected']
    print "Reference:", execute_schedule_ref(assigment, permutation, alg_performance_data)
    print "Optimized", execute_schedule_fast(assigment, permutation, alg_performance_data)

def do_test_instance_fast(instance):
    assigment = instance['assigment']
    permutation = instance['permutation']
    alg_performance_data = instance['alg_performance_data']
    return execute_schedule_fast(assigment, permutation, alg_performance_data)

def do_test_instance_ref(instance):
    assigment = instance['assigment']
    permutation = instance['permutation']
    alg_performance_data = instance['alg_performance_data']
    return execute_schedule_ref(assigment, permutation, alg_performance_data)

if __name__ == "__main__":

    for instance in test_instances:
        do_test_instance_all(instance)
        print ""
#        print instance['expected'] - do_test_instance_ref(instance)
