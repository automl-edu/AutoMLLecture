# -*- coding: utf-8 -*-
import arff
import sys
from optparse import OptionParser
import numpy as np

class AlgPerfomanceData:
    '''
    A class to parse the alrogithm performance data from an arff file and
    provide easy access to it.
    '''

    def __init__(self, filename):
        '''
        Parses an arff file and precomputes some summary information about it.
        @param filename: the filename of the arff file
        '''
        self.alg_runs_dict = dict()
        self.algorithms = set()
        self.instances = set()
        with open(filename, 'r') as fhandler:
            for run in arff.load(fhandler)['data']:
                instance_name, _, algorithm_name, runtime, runstatus = run
                self.alg_runs_dict[(algorithm_name, instance_name)] = {"time": runtime, "status": runstatus}
                self.algorithms.add(algorithm_name)
                self.instances.add(instance_name)
        self.max_runtimes = dict()
        self.min_runtimes = dict()
        self.algorithms = sorted(list(self.algorithms))
        self.instances = sorted(list(self.instances))
        for alg in self.algorithms:
            self.max_runtimes[alg] = max([self.m(inst, alg) for inst in self.instances])
            self.min_runtimes[alg] = min([self.m(inst, alg) for inst in self.instances])

        self.fast_access_array = np.empty((len(self.instances), len(self.algorithms)), dtype=float)
        for inst_id, inst in enumerate(self.instances):
            for alg_id, alg in enumerate(self.algorithms):
                self.fast_access_array[inst_id, alg_id] = self.m(inst, alg)

        self.alg_ids = dict([(alg, alg_id) for alg_id, alg in enumerate(self.algorithms)])
        self.inst_ids = dict([(inst, inst_id) for inst_id, inst in enumerate(self.instances)])

    def m(self, instance, algorithm):
        '''
        Returns the PAR10 performance of a given algorithm on a given instnace.
        Will throw a key error if either algorithm or instance are unknown.
        @param instance: A string representing the instance name/key
        @param algorithm: A string representing the algorithms name
        @return the algorithms runtime on the instance if the status of the run is 'ok', the algorithms runtime times 10 otherwise
        '''
        run_info = self.alg_runs_dict[(algorithm, instance)]
        return run_info['time'] if run_info['status'] == 'ok' else run_info['time'] * 10

    def get_best_alg(self, instance):
        '''
        Returns the best algorithm for instnace
        '''
        best_alg = self.algorithms[0]
        best_perf = self.m(instance, best_alg)
        for alg in self.algorithms:
            perf = self.m(instance, alg)
            if perf < best_perf:
                best_perf, best_alg = perf, alg

        return best_alg

    def max_runtime(self, alg):
        '''
        Returns the maximum runtime for any given algorithm over all instances
        '''
        return self.max_runtime[alg]

    def min_runtimes(self, alg):
        '''
        Returns the minimum runtime for any given algorithm over all instances
        '''
        return self.min_runtimes[alg]

    def single_best(self):
        '''
        Returns the the cumulated runtime (over all instnace) that the
        algorithm that did was fastest (whenn summing over all instances)
        '''
        return min([sum([self.m(inst, alg) for inst in self.instances]) for alg in self.algorithms])/len(self.instances)

    def oracle(self):
        '''
        Returns the runtime if for each instance, the algorithm which performs
        best on that instance is choosen.
        '''
        return sum([min([self.m(inst, alg) for alg in self.algorithms]) for inst in self.instances])/len(self.instances)

def main(argv):
    # Parse command line options
    parser = OptionParser()
    parser.add_option("-a", "--algoruns", type="string", dest="filename",
                  help="Read algorithms runs from file", metavar="FILE")

    options, args = parser.parse_args()
    if options.filename is None:
        parser.error('filename not given')

    # Load and parse algorithm performance data
    performanceData = AlgPerfomanceData(options.filename)

    # Print algorithm performance data
    print "Oracle:", performanceData.oracle()
    print "SB:", performanceData.single_best()

if __name__ == "__main__":
    main(sys.argv[1:])
