#!/usr/bin/python
import arff
import sys, getopt
import random
from optparse import OptionParser
import copy
from aslib_stats import AlgPerfomanceData
from virtual_schedule_execution_reference import execute_schedule_fast
import time

timeout = 5000.
verbose = False

def RandomizedHillClimbing(assigment, permutation, data, runs_filename):
    '''
    Implementation  of hill climbing that randomly picked neighbours and go towards not decreasing performance
    Two types of choosing neighbour strategies are used:
    1) Change two values in permutation
    2) Shift random interval of time from one algorithm to another
    '''
    alg_performance_data = AlgPerfomanceData(runs_filename)
    algorithms = alg_performance_data.algorithms

    saved_assigment = assigment
    saved_permutation = permutation

    saved_performance = execute_schedule_fast(assigment, permutation, alg_performance_data)
    best_performance = execute_schedule_fast(assigment, permutation, alg_performance_data)

    steps_without_changing = 0

    for i in range(0, 1000000*4):
        steps_without_changing += 1
        to_exchange = random.sample(xrange(0, len(algorithms)), 2)
        i1, i2 = to_exchange[0], to_exchange[1]
        permutation[i1], permutation[i2] = permutation[i2], permutation[i1]
        performance = execute_schedule_fast(assigment, permutation, alg_performance_data)
        if performance <= best_performance:
            best_performance = performance
            if (i % 10000) == 0 and verbose:
                print i, best_performance
            steps_without_changing = 0
        else:
            permutation[i1], permutation[i2] = permutation[i2], permutation[i1]

        to_time_slice = random.sample(algorithms, 2)
        i1, i2 = to_time_slice[0], to_time_slice[1]
        if int(min(assigment[i1], assigment[i2])) == 0:
            continue

        time_slice = random.uniform(0.001, min(assigment[i1], timeout - assigment[i2]))
        assigment[i1] -= time_slice
        assigment[i2] += time_slice
        performance = execute_schedule_fast(assigment, permutation, alg_performance_data)
        if performance <= best_performance:
            best_performance = performance
            if (i % 10000) == 0 and verbose:
                print i, best_performance
            steps_without_changing = 0
        else:
            assigment[i1] += time_slice
            assigment[i2] -= time_slice

        if steps_without_changing > 10000:
            # After 10000 steps without changing we conclude that we stuck in local minima
            # and we do random jump to some place in search space
            steps_without_changing = 0
            if best_performance < saved_performance:
                # Save this local minima as best founded
                saved_assigment = copy.copy(assigment)
                saved_permutation = copy.copy(permutation)
                saved_performance = best_performance

            (assigment, permutation) = (dict([(i, timeout/len(algorithms)) for i in algorithms]), [i for i in algorithms])
            random.shuffle(permutation)

            best_performance = execute_schedule_fast(assigment, permutation, alg_performance_data)

    if best_performance < saved_performance:
        saved_assigment = assigment
        saved_permutation = copy.copy(permutation)
        saved_performance = best_performance

    if verbose:
        print best_performance
        print saved_performance
    return (saved_assigment, saved_permutation)

def get_optimal_schedule(data, runs_filename):
    algorithms = set([i[2] for i in data["data"]])
    (assigment, permutation) = (dict([(i, timeout/len(algorithms)) for i in algorithms]), [i for i in algorithms])

    return RandomizedHillClimbing(assigment, permutation, data, runs_filename)

def main(argv):
    global verbose
    parser = OptionParser()
    parser.add_option("-a", "--algoruns", type="string", dest="filename",
                  help="Read algorithms runs from file", metavar="FILE")
    parser.add_option("-v", "--verbose", dest="verbose", action="store_true",
                  help="Provide more information during algorithm run")

    (options, args) = parser.parse_args()
    if options.filename is None:
        parser.error('filename not given')

    if options.verbose:
        verbose = True

    data = arff.load(open(options.filename))
    t0 = time.time()
    (assigment, permutation) = get_optimal_schedule(data, options.filename)
    if verbose :
        print "it took {} seconds".format(time.time() - t0)
    print "assignment:", assigment
    print "permutation:", permutation

if __name__ == "__main__":
    main(sys.argv[1:])
