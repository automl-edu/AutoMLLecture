import arff
import argparse


class AlgoPerformance(object):
    """ Wrapper class for Algorithm Performance """
    def __init__(self, algorithm_name):
        super(AlgoPerformance, self).__init__()
        self.algorithm_name = algorithm_name
        # dict: instance -> (no_runs, total_runtime)
        self.total_runtime_on = {}
        self.total_runtime = 0.0
        self.no_runs = 0

    def __repr__(self):
        # Prettyprinting of schedules for debugging
        return "\""+self.algorithm_name+"\""

    # Added hash and eq method to be able to use algoperformance objects
    # as dictionary keys for schedules
    def __hash__(self):
        return hash(self.algorithm_name)

    def __eq__(self, other):
        return self.algorithm_name == other.algorithm_name

    def add_run(self, instance, runtime, status):
        computed_runtime = runtime
        if status != 'ok':
            # run failed, penalize the runtime of this run
            computed_runtime = 10 * 5000

        self.no_runs += 1
        self.total_runtime += computed_runtime

        if instance in self.total_runtime_on:
            # Update existing runtime
            self.total_runtime_on[instance][0] += 1
            self.total_runtime_on[instance][1] += computed_runtime
        else:
            # insert new runtime
            self.total_runtime_on[instance] = (1, computed_runtime)

    def overall_avg_runtime(self):
        return self.total_runtime / (float(self.no_runs))

    def avg_runtime_on(self, instance):
        runs_on_instance = self.total_runtime_on[instance][0]
        total_runtime_on_instance = self.total_runtime_on[instance][1]
        return total_runtime_on_instance / (float(runs_on_instance))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--algoruns', required=True, help="""(Full) path to
            algoruns file containing algorithm performance data (suffix .arff)""")
    args = parser.parse_args()

    algoruns = args.algoruns
    data = arff.load(open(algoruns, 'rb'))

    # Collect algorithm performances in dictionary
    all_algo_performances = {}

    # maintain list of all instances to compute oracle later
    all_instances = list(set([run[0] for run in data['data']]))

    for run in data['data']:
        instance_id = run[0]
        repetition = run[1]
        algo = run[2]
        runtime = run[3]
        runstatus = run[4]

        if algo not in all_algo_performances:
            all_algo_performances[algo] = AlgoPerformance(algo)

        all_algo_performances[algo].add_run(instance_id, runtime, runstatus)

    # Compute single best algo and runtime and print it..
    performance_list = [(algo.algorithm_name, algo.overall_avg_runtime()) for algo in
            all_algo_performances.values()]

    (single_best, avg_runtime) = min(performance_list, key = lambda t: t[1])


    # compute oracle configuration
    oracle = []
    for instance in all_instances:
        performances_on_instance = [(algo.algorithm_name,
            algo.avg_runtime_on(instance)) for algo in
            all_algo_performances.values()]
        oracle.append((instance, min(performances_on_instance, key = lambda
            t:t[1])))
    # compute oracle average performance
    oracle_avg_runtime = ((sum([config[1][1] for config in oracle]))
            / float(len(oracle)))

    # Print results
    print("Oracle: %s"%(str(oracle_avg_runtime)))
    print("SB: %s"%(str(avg_runtime)))

if __name__ == "__main__":
    main()
