import arff
import datetime
import random
import sys
import os
sys.path.append(os.path.abspath("."))
from aslib_stats import AlgoPerformance
import argparse
import json


def wouldTimeOut(schedule, instance):
# Decide if the given schedule would time out on the given instance
    for (algoperf, timeslice) in schedule.iteritems():
        # If the current algorithm is known to solve 'instance' within
        # his timeslice, then we do not time out
        if algoperf.avg_runtime_on(instance) <= timeslice:
            return False
    return True

def countTimeOuts(schedule, all_instances):
# count the number of timeouts a given schedule would produce on all instances
    return sum([wouldTimeOut(schedule, instance) for instance in all_instances])

def single_step(schedule):
    """ Generate a neighbour of the given schedule by changing time slices for
    two algorithms in a way that preserves the fact that the sum of all
    timeslices never exceeds 5000 """
    [first_sample, second_sample] = random.sample(schedule, 2)
    # random sample an amount from [0, timeslice(second_sample)]
    # => implicitly ensures, that we can never exceed/get below
    # 5000 for the sum of all timeslices
    update_amount = random.uniform(0, schedule[second_sample])
    schedule[first_sample] += update_amount
    schedule[second_sample] -= update_amount
    return schedule

def random_schedule(algo_performances):
    """ Generate a random schedule by assigning random time slices to all
    algorithms in @param:algo_performances and ensure they sum up to 5000.0 """
    no_algos = len(algo_performances)
    # construct list of uniform random variables that will become timeslices
    random_list = [random.random() for i in range(no_algos)]
    # compute the sum of the variables for normalization
    sum_randoms = sum(random_list)
    # Normalize each variable and multiply it by 5000 to get random timeslices
    timeslices = [(float(i) / sum_randoms) * 5000 for i in random_list]

    algorithms = algo_performances.values()

    random_schedule = { algorithms[i] : timeslices[i] for i in range(no_algos) }

    assert(abs(sum(timeslices) - 5000.0) < 0.01)

    return random_schedule




def apply_rii_step(current_best, current_schedule, all_instances, wp, maxSteps,
                    verbose=False):
    """ Apply a single iteration of rii for a given number of maxSteps """

    stepsInLoop = maxSteps
    if verbose:
        print("Steps remaining:" , maxSteps)

    if current_best == 0 or maxSteps == 0:
        # If the current schedule produces no timeouts, just keep it, we can't
        # do better..
        return (current_schedule, current_best)

    # Ensures that the while loop is visited at least once
    new_quality = float("inf")

    while current_best <= new_quality:
        if verbose:
            print("IN LOOP: %d STEPS REMAIN"% maxSteps)
    # while no better neighbour was found do...
        neighbour = current_schedule.copy() #construct new neighbour schedule
        neighbour = single_step(neighbour) #apply single update
        new_quality = countTimeOuts(neighbour, all_instances) #recompute quality
        maxSteps -= 1
        if maxSteps < 0:
            return (current_schedule, current_best)

    # Call recursively with new better solution
    return apply_rii_step(new_quality, neighbour, all_instances, wp, stepsInLoop,
                            verbose)


def computePAR10(schedule, order, all_instances):
    par10 = 0.0
    for instance in all_instances:
        if wouldTimeOut(schedule, instance):
            # If schedule times out on the given instance, penalize the runtime
            par10 += 5000.0 * 10.0
        else:
            # schedule won't time out
            for algo in order:
                algoruntime = algo.avg_runtime_on(instance)
                if algoruntime <= schedule[algo]:
                 # algo solved instance, add its runtime, then get the next
                 # instance
                 par10 += algoruntime
                 break;
                else:
                    # algo didn't solve the instance in his timeslice,
                    # add its timeslice to the costs, then keep moving
                    par10 += schedule[algo]
    return (par10 / float(len(all_instances)))



def main():
    ############################# PARSE ARGUMENTS #############################
    parser = argparse.ArgumentParser()
    parser.add_argument('--algoruns', required=True, help="""(Full) path to
            algoruns file containing algorithm performance data (suffix .arff)""")
    parser.add_argument('--verbose',required=False, help="""Print more
    information, in particular the performance""")
    args = parser.parse_args()

    algoruns = args.algoruns
    if args.verbose:
        verbose = True
    else:
        verbose = False
    data = arff.load(open(algoruns, 'rb'))
    ###########################################################################


    ############################# PROCESS DATA ################################

    all_algo_performances = {}
    all_instances = []

    for run in data['data']:
        instance_id = run[0]
        repetition = run[1]
        algo = run[2]
        runtime = run[3]
        runstatus = run[4]

        if algo not in all_algo_performances:
            all_algo_performances[algo] = AlgoPerformance(algo)

        all_algo_performances[algo].add_run(instance_id, runtime, runstatus)
        all_instances.append(instance_id)

    ###########################################################################

    ################# SEARCH FOR TIME-OUT MINIMIZING SCHEDULE #################
    initial_timeslice = (5000.0 / (float(len(all_algo_performances))))
    initial_schedule = random_schedule(all_algo_performances)
    # Initialize best schedule and its quality measure
    best_schedule = initial_schedule.copy()
    initial_quality = countTimeOuts(initial_schedule, all_instances)
    best_quality = initial_quality


    #endtime_schedule_search = datetime.datetime.now() +datetime.timedelta(minutes=3)
    endtime_schedule_search=datetime.datetime.now()+datetime.timedelta(seconds=190)
    while datetime.datetime.now() < endtime_schedule_search:
        # Start randomized iterative improvement with a random schedule for a
        # certain amount of iterations
        rand_schedule = random_schedule(all_algo_performances)
        start_quality = countTimeOuts(rand_schedule, all_instances)
        (schedule, quality) = apply_rii_step(start_quality,
                rand_schedule,
                all_instances, 0.3, 200, verbose=False)
        if quality < best_quality:
            # Better schedule found, update best schedule
            best_schedule = schedule.copy()
            best_quality = quality

    ###########################################################################

    ########### SEARCH FOR PAR10-MINIMIZING ALGORITHM PERMUTATION #############
    endtime_permutation_search = datetime.datetime.now() +datetime.timedelta(seconds=80)
    initial_order = best_schedule.keys()
    best_order = initial_order
    bestPAR10 = computePAR10(best_schedule, initial_order, all_instances)
    while datetime.datetime.now() < endtime_permutation_search:
        curr_order = best_order
        # swap two random elements in the current permutation
        i = random.choice(range(len(curr_order)))
        j = random.choice(range(len(curr_order)))
        curr_order[i], curr_order[j] = curr_order[j], curr_order[i]
        new_par10 = computePAR10(best_schedule, curr_order, all_instances)
        if new_par10 < bestPAR10:
            # found a better permutation
            bestPAR10 = new_par10
            best_order = curr_order
    print(best_schedule)
    print("assignment: " + str(best_schedule))
    print("permutation: " + str(best_order))
    if verbose:
        print(bestPAR10)



    ###########################################################################



if __name__ == "__main__":
    main()
